import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import { 
  Database, 
  FileSpreadsheet, 
  Upload, 
  Download, 
  Search, 
  Filter, 
  RefreshCw, 
  Sparkles, 
  ArrowLeftRight, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Mail, 
  Grid, 
  TrendingUp, 
  Layers, 
  FileDown, 
  Trash2, 
  Sliders, 
  ArrowRight,
  Info,
  ExternalLink,
  Briefcase,
  ArrowUpDown,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { ERPType, RawRow, KarvySummaryRow, TrailERPSummaryRow, ERPStats } from './types';
import { 
  fmtDate, 
  fmtNum, 
  serialToDate, 
  mapColumnNames, 
  consolidateKarvy, 
  buildKarvySummary, 
  processTrailERP, 
  buildTrailERPSummary 
} from './utils';

// Framer Motion staggered entrance animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.02
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  show: { 
    opacity: 1, 
    y: 0,
    transition: {
      type: "spring",
      stiffness: 110,
      damping: 14,
      mass: 0.9
    }
  }
};

export default function App() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [hoveredStat, setHoveredStat] = useState<string | null>(null);

  // Portal Selection State
  const [activeERP, setActiveERP] = useState<ERPType>(() => {
    const saved = localStorage.getItem('last_selected_erp');
    return (saved === 'karvy' || saved === 'trail_erp') ? saved : null;
  });

  // Remember User Selection
  const selectERP = (type: ERPType) => {
    setActiveERP(type);
    if (type) {
      localStorage.setItem('last_selected_erp', type);
    } else {
      localStorage.removeItem('last_selected_erp');
    }
    // Reset active tab and tables when switching
    setActiveSubPage('overview');
    resetCurrentToolState();
  };

  // Sub-Navigation within the selected tool
  const [activeSubPage, setActiveSubPage] = useState<'overview' | 'cleaner' | 'database' | 'analytics'>('overview');

  // Real-time Metadata
  const [localTime, setLocalTime] = useState<string>('2026-06-25 21:51:57');
  const userEmail = 'parita25382@gmail.com';

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      // Keep format similar to provided metadata
      const yyyy = now.getFullYear();
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const dd = String(now.getDate()).padStart(2, '0');
      const hh = String(now.getHours()).padStart(2, '0');
      const min = String(now.getMinutes()).padStart(2, '0');
      const ss = String(now.getSeconds()).padStart(2, '0');
      setLocalTime(`${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Shared Upload/Process States
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);
  const [progressMsg, setProgressMsg] = useState('');
  const [logs, setLogs] = useState<{ type: 'ok' | 'warn' | 'info'; text: string }[]>([]);
  const [fileName, setFileName] = useState<string>('');

  // Karvy-specific Data
  const [karvyRawData, setKarvyRawData] = useState<RawRow[]>([]);
  const [karvyCleanedRows, setKarvyCleanedRows] = useState<RawRow[]>([]);
  const [karvySummaryRows, setKarvySummaryRows] = useState<KarvySummaryRow[]>([]);
  const [karvyHeaders, setKarvyHeaders] = useState<string[]>([]);
  const [karvyColumnMap, setKarvyColumnMap] = useState<Record<string, string | null>>({});

  // Karvy Filters & Pagination
  const [kSearch, setKSearch] = useState('');
  const [kFilterInvestor, setKFilterInvestor] = useState('');
  const [kFilterFolio, setKFilterFolio] = useState('');
  const [kFilterScheme, setKFilterScheme] = useState('');
  const [kFilterHead, setKFilterHead] = useState('');
  const [kFilterDesc, setKFilterDesc] = useState('');
  const [kPage, setKPage] = useState(1);
  const [kSortField, setKSortField] = useState<keyof KarvySummaryRow | ''>('');
  const [kSortOrder, setKSortOrder] = useState<'asc' | 'desc'>('asc');
  const [expandedKarvyRows, setExpandedKarvyRows] = useState<Record<string, boolean>>({});

  // Trail ERP-specific Data
  const [trailRawData, setTrailRawData] = useState<RawRow[]>([]);
  const [trailCleanedRows, setTrailCleanedRows] = useState<RawRow[]>([]);
  const [trailSummaryRows, setTrailERPSummaryRows] = useState<TrailERPSummaryRow[]>([]);
  const [trailHeaders, setTrailHeaders] = useState<string[]>([]);

  // Trail ERP Filters & Pagination
  const [tSearch, setTSearch] = useState('');
  const [tFilterType, setTFilterType] = useState('');
  const [tFilterInvestor, setTFilterInvestor] = useState('');
  const [tFilterFolio, setTFilterFolio] = useState('');
  const [tFilterScheme, setTFilterScheme] = useState('');
  const [tPage, setTPage] = useState(1);
  const [tSortField, setTSortField] = useState<keyof TrailERPSummaryRow | ''>('');
  const [tSortOrder, setTSortOrder] = useState<'asc' | 'desc'>('asc');
  const [expandedTrailRows, setExpandedTrailRows] = useState<Record<string, boolean>>({});

  // Reset tool state
  const resetCurrentToolState = () => {
    setLogs([]);
    setFileName('');
    setProgressPercent(0);
    setProgressMsg('');
    setIsLoading(false);

    // Reset Karvy Data
    setKarvyRawData([]);
    setKarvyCleanedRows([]);
    setKarvySummaryRows([]);
    setKarvyHeaders([]);
    setKarvyColumnMap({});
    setKSearch('');
    setKFilterInvestor('');
    setKFilterFolio('');
    setKFilterScheme('');
    setKFilterHead('');
    setKFilterDesc('');
    setKPage(1);
    setKSortField('');
    setKSortOrder('asc');
    setExpandedKarvyRows({});

    // Reset Trail ERP Data
    setTrailRawData([]);
    setTrailCleanedRows([]);
    setTrailERPSummaryRows([]);
    setTrailHeaders([]);
    setTSearch('');
    setTFilterType('');
    setTFilterInvestor('');
    setTFilterFolio('');
    setTFilterScheme('');
    setTPage(1);
    setTSortField('');
    setTSortOrder('asc');
    setExpandedTrailRows({});
  };

  const addLog = (text: string, type: 'ok' | 'warn' | 'info' = 'info') => {
    setLogs(prev => [...prev, { type, text }]);
  };

  // Drag & Drop Handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      processFile(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Process Real Excel File
  const processFile = (file: File) => {
    setFileName(file.name);
    setIsLoading(true);
    setProgressMsg('Reading uploaded file...');
    setProgressPercent(15);
    setLogs([]);
    addLog(`Initiating import of "${file.name}"`, 'info');

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        setProgressMsg('Parsing Excel spreadsheet...');
        setProgressPercent(40);
        
        const dataBytes = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(dataBytes, { type: 'array' });
        
        // Pick first non-empty worksheet
        let worksheetName = '';
        for (const name of workbook.SheetNames) {
          const sheet = workbook.Sheets[name];
          if (sheet['!ref'] && sheet['!ref'] !== 'A1') {
            worksheetName = name;
            break;
          }
        }
        
        if (!worksheetName) {
          throw new Error('No valid populated worksheet was found in this file.');
        }

        addLog(`Located data worksheet: "${worksheetName}"`, 'info');
        const sheet = workbook.Sheets[worksheetName];
        
        // Parse rows as raw array of arrays
        const rawJson: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
        if (rawJson.length < 2) {
          throw new Error('The worksheet contains insufficient rows for processing (minimum header + 1 data row required).');
        }

        const headers = rawJson[0].map((h: any) => String(h).trim());
        
        // Map raw arrays to Objects
        const records: RawRow[] = [];
        for (let i = 1; i < rawJson.length; i++) {
          const rowData = rawJson[i];
          const record: RawRow = {};
          let hasVal = false;
          headers.forEach((header, idx) => {
            const val = rowData[idx];
            record[header] = val !== undefined ? val : '';
            if (val !== '' && val !== null && val !== undefined) {
              hasVal = true;
            }
          });
          if (hasVal) {
            records.push(record);
          }
        }

        setProgressMsg('Executing custom ERP deduplication and rate aggregation rules...');
        setProgressPercent(75);

        if (activeERP === 'karvy') {
          // Verify Karvy Columns
          const mappedCols = mapColumnNames(headers);
          setKarvyHeaders(headers);
          setKarvyColumnMap(mappedCols);

          const required = ['trxnno', 'pct', 'brok', 'head', 'investor'];
          const missing = required.filter(k => mappedCols[k] === null);
          if (missing.length > 0) {
            const missingNames = missing.map(m => m.toUpperCase());
            throw new Error(`Invalid format. Missing required columns or close matches for: ${missingNames.join(', ')}`);
          }

          addLog(`Mapped critical headers for Karvy: Transaction Number="${mappedCols.trxnno}", Rate="${mappedCols.pct}", Brokerage="${mappedCols.brok}"`, 'ok');

          // Process
          const cleaned = consolidateKarvy(records, mappedCols);
          const summaries = buildKarvySummary(cleaned, mappedCols);

          setKarvyRawData(records);
          setKarvyCleanedRows(cleaned);
          setKarvySummaryRows(summaries);

          addLog(`Successfully consolidated ${records.length} raw records into ${cleaned.length} unique transaction rows.`, 'ok');
          addLog(`Removed/Merged ${records.length - cleaned.length} rows using same Transaction Numbers.`, 'warn');
        } else {
          // Trail ERP v2
          setTrailHeaders(headers);
          const hdLower = headers.map(h => h.toLowerCase());
          const required = ['folio', 'investor name', 'trxn_db_cr', 'rate', 'trxn_no', 'short_name', 'procdate'];
          const missing = required.filter(r => !hdLower.includes(r));
          
          if (missing.length > 0) {
            throw new Error(`Invalid Trail ERP format. Missing required columns: ${missing.join(', ')}`);
          }

          const cleaned = processTrailERP(records, headers);
          const summaries = buildTrailERPSummary(cleaned);

          setTrailRawData(records);
          setTrailCleanedRows(cleaned);
          setTrailERPSummaryRows(summaries);

          addLog(`Processed ${records.length} raw rows. Generated ${cleaned.length} rate-consolidated rows.`, 'ok');
          addLog(`Aggregated/Deduplicated ${records.length - cleaned.length} multi-tier rate slab records.`, 'warn');
        }

        setProgressPercent(100);
        setProgressMsg('Cleanse and aggregation completed successfully!');
        
        setTimeout(() => {
          setIsLoading(false);
          // Auto route to data dashboard so they can inspect immediately
          setActiveSubPage('database');
        }, 500);

      } catch (err: any) {
        setIsLoading(false);
        setProgressPercent(0);
        addLog(`Processing Error: ${err.message}`, 'warn');
        alert(`ERP File Error: ${err.message}`);
      }
    };

    reader.onerror = () => {
      setIsLoading(false);
      addLog('Failed to read the file correctly. Please make sure the document is not corrupted.', 'warn');
    };

    reader.readAsArrayBuffer(file);
  };

  // Load High-Quality Mock Demonstration Data
  const loadDemoData = () => {
    setIsLoading(true);
    setProgressMsg('Loading high-fidelity demonstration workspace...');
    setProgressPercent(30);
    setLogs([]);
    setFileName('executive_demo_dataset.xlsx');

    setTimeout(() => {
      if (activeERP === 'karvy') {
        const demoHeaders = [
          'Account No', 'Investor Name', 'Fund Description', 'Transaction Description', 
          'Transaction Date', 'Transaction Number', 'Amount (in Rs.)', 'Units', 
          'Percentage (%)', 'Brokerage (in Rs.)', 'Brokerage Head'
        ];
        
        const demoRaw = [
          // Amit Sharma - Trxn 1001 (LongTermTrailFee and Addtrail to sum)
          { 'Account No': 'FOLIO-88123', 'Investor Name': 'Amit Sharma', 'Fund Description': 'Axis Bluechip Growth Fund', 'Transaction Description': 'SIP Purchase', 'Transaction Date': '10-Jun-2026', 'Transaction Number': '1000101', 'Amount (in Rs.)': 50000, 'Units': '1250.450', 'Percentage (%)': 0.50, 'Brokerage (in Rs.)': 250.00, 'Brokerage Head': 'LongTermTrailFee' },
          { 'Account No': 'FOLIO-88123', 'Investor Name': 'Amit Sharma', 'Fund Description': 'Axis Bluechip Growth Fund', 'Transaction Description': 'SIP Purchase', 'Transaction Date': '10-Jun-2026', 'Transaction Number': '1000101', 'Amount (in Rs.)': 50000, 'Units': '1250.450', 'Percentage (%)': 0.25, 'Brokerage (in Rs.)': 125.00, 'Brokerage Head': 'Addtrail' },
          
          // Priya Patel - Trxn 1002 (Annualized and SIPSTP AddIncentiveAnual to sum)
          { 'Account No': 'FOLIO-99544', 'Investor Name': 'Priya Patel', 'Fund Description': 'SBI Small Cap Direct', 'Transaction Description': 'Systematic Transfer In', 'Transaction Date': '12-Jun-2026', 'Transaction Number': '2000202', 'Amount (in Rs.)': 100000, 'Units': '850.120', 'Percentage (%)': 0.60, 'Brokerage (in Rs.)': 600.00, 'Brokerage Head': 'Annualized' },
          { 'Account No': 'FOLIO-99544', 'Investor Name': 'Priya Patel', 'Fund Description': 'SBI Small Cap Direct', 'Transaction Description': 'Systematic Transfer In', 'Transaction Date': '12-Jun-2026', 'Transaction Number': '2000202', 'Amount (in Rs.)': 100000, 'Units': '850.120', 'Percentage (%)': 0.15, 'Brokerage (in Rs.)': 150.00, 'Brokerage Head': 'SIPSTP AddIncentiveAnual' },
          
          // Rajesh Mehta - Trxn 1003 (Identical Head Sublots to group and sum units & brokerage)
          { 'Account No': 'FOLIO-33211', 'Investor Name': 'Rajesh Mehta', 'Fund Description': 'HDFC Top 100 Fund', 'Transaction Description': 'Lump Sum Purchase', 'Transaction Date': '15-Jun-2026', 'Transaction Number': '3000303', 'Amount (in Rs.)': 80000, 'Units': '1000.000', 'Percentage (%)': 0.80, 'Brokerage (in Rs.)': 640.00, 'Brokerage Head': 'LongTermTrailFee' },
          { 'Account No': 'FOLIO-33211', 'Investor Name': 'Rajesh Mehta', 'Fund Description': 'HDFC Top 100 Fund', 'Transaction Description': 'Lump Sum Purchase', 'Transaction Date': '15-Jun-2026', 'Transaction Number': '3000303', 'Amount (in Rs.)': 80000, 'Units': '500.000', 'Percentage (%)': 0.80, 'Brokerage (in Rs.)': 320.00, 'Brokerage Head': 'LongTermTrailFee' },
          
          // Sarah Jenkins - No Merge
          { 'Account No': 'FOLIO-55412', 'Investor Name': 'Sarah Jenkins', 'Fund Description': 'Mirae Asset Large Cap', 'Transaction Description': 'SIP Purchase', 'Transaction Date': '18-Jun-2026', 'Transaction Number': '4000404', 'Amount (in Rs.)': 15000, 'Units': '412.300', 'Percentage (%)': 0.40, 'Brokerage (in Rs.)': 60.00, 'Brokerage Head': 'SIPSTP AddIncentiveTrail' }
        ];

        setKarvyHeaders(demoHeaders);
        const mappedCols = mapColumnNames(demoHeaders);
        setKarvyColumnMap(mappedCols);

        addLog('Loaded 7 demo records representing complex trail structures.', 'info');
        setProgressPercent(65);
        setProgressMsg('Aggregating sub-lots and summing percentage rates...');

        setTimeout(() => {
          const cleaned = consolidateKarvy(demoRaw, mappedCols);
          const summaries = buildKarvySummary(cleaned, mappedCols);

          setKarvyRawData(demoRaw);
          setKarvyCleanedRows(cleaned);
          setKarvySummaryRows(summaries);

          addLog('Completed: Consoles grouped by Transaction ID. Rate % combined.', 'ok');
          addLog('Amit Sharma 1000101: rate consolidated to 0.75%, brokerage ₹375.00', 'ok');
          addLog('Rajesh Mehta 3000303: units summed to 1500.000, brokerage ₹960.00', 'ok');

          setProgressPercent(100);
          setIsLoading(false);
          setActiveSubPage('database');
        }, 500);

      } else {
        // Trail ERP Demo
        const demoHeaders = [
          'folio', 'investor name', 'short_name', 'procdate', 'trxn_no', 
          'trxn_db_cr', 'units', 'amount', 'rate', 'fee_desc', 
          'fee_amt', 'avg_assets', 'fee_type', 'days_fee_paid'
        ];

        const demoRaw = [
          // Rajesh Mehta - Same key cols but different rates (1.0% + 0.25% = 1.25%)
          { folio: '123456', 'investor name': 'Rajesh Mehta', short_name: 'HDFC Top 100', procdate: 46190, trxn_no: '5001', trxn_db_cr: 'P', units: 100.5, amount: 10000, rate: 1.0, fee_desc: 'Trail Base', fee_amt: '100.00', avg_assets: '10000.00', fee_type: 'Standard', days_fee_paid: '30' },
          { folio: '123456', 'investor name': 'Rajesh Mehta', short_name: 'HDFC Top 100', procdate: 46190, trxn_no: '5001', trxn_db_cr: 'P', units: 100.5, amount: 10000, rate: 0.25, fee_desc: 'Trail AddIncentive', fee_amt: '25.00', avg_assets: '10000.00', fee_type: 'Bonus', days_fee_paid: '30' },
          
          // Sunita Rao - Same key cols (0.85% + 0.15% = 1.00%)
          { folio: '987654', 'investor name': 'Sunita Rao', short_name: 'ICICI Pru Bluechip', procdate: 46195, trxn_no: '5002', trxn_db_cr: 'SI', units: 50.25, amount: 5000, rate: 0.85, fee_desc: 'SIP Base', fee_amt: '42.50', avg_assets: '5000.00', fee_type: 'Regular', days_fee_paid: '30' },
          { folio: '987654', 'investor name': 'Sunita Rao', short_name: 'ICICI Pru Bluechip', procdate: 46195, trxn_no: '5002', trxn_db_cr: 'SI', units: 50.25, amount: 5000, rate: 0.15, fee_desc: 'SIP Extra', fee_amt: '7.50', avg_assets: '5000.00', fee_type: 'Extra', days_fee_paid: '30' },
          
          // Dr. Vikram Sen - TI Transfer In (No merge, single entry)
          { folio: '445566', 'investor name': 'Dr. Vikram Sen', short_name: 'SBI Nifty Index Fund', procdate: 46200, trxn_no: '5003', trxn_db_cr: 'TI', units: 1500, amount: 150000, rate: 0.50, fee_desc: 'Standard TI Fee', fee_amt: '75.00', avg_assets: '150000.00', fee_type: 'Standard', days_fee_paid: '31' }
        ];

        setTrailHeaders(demoHeaders);
        addLog('Loaded 5 premium trail records with multi-rate schemas.', 'info');
        setProgressPercent(65);
        setProgressMsg('Summing rate slabs matching exact Folio + Schemes...');

        setTimeout(() => {
          const cleaned = processTrailERP(demoRaw, demoHeaders);
          const summaries = buildTrailERPSummary(cleaned);

          setTrailRawData(demoRaw);
          setTrailCleanedRows(cleaned);
          setTrailERPSummaryRows(summaries);

          addLog('Deduplication logic applied successfully.', 'ok');
          addLog('Rajesh Mehta Trxn 5001 combined rate: 1.25% (Base + AddIncentive)', 'ok');
          addLog('Sunita Rao Trxn 5002 combined rate: 1.00% (SIP Base + SIP Extra)', 'ok');

          setProgressPercent(100);
          setIsLoading(false);
          setActiveSubPage('database');
        }, 500);
      }
    }, 600);
  };

  const handleKarvySort = (field: keyof KarvySummaryRow) => {
    if (kSortField === field) {
      setKSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setKSortField(field);
      setKSortOrder('asc');
    }
  };

  const handleTrailSort = (field: keyof TrailERPSummaryRow) => {
    if (tSortField === field) {
      setTSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setTSortField(field);
      setTSortOrder('asc');
    }
  };

  const renderSortableHeader = (
    label: string, 
    field: string, 
    type: 'karvy' | 'trail',
    alignRight: boolean = false,
    extraClass: string = ''
  ) => {
    const isActive = type === 'karvy' ? kSortField === field : tSortField === field;
    const order = type === 'karvy' ? kSortOrder : tSortOrder;
    const handleSort = () => {
      if (type === 'karvy') {
        handleKarvySort(field as keyof KarvySummaryRow);
      } else {
        handleTrailSort(field as keyof TrailERPSummaryRow);
      }
    };

    return (
      <th 
        onClick={handleSort}
        className={`p-4 font-display cursor-pointer hover:bg-accent-cream/80 transition-colors group select-none ${alignRight ? 'text-right' : 'text-left'} ${extraClass}`}
      >
        <div className={`flex items-center gap-1.5 ${alignRight ? 'justify-end' : 'justify-start'}`}>
          <span>{label}</span>
          <ArrowUpDown className={`w-3.5 h-3.5 transition-opacity ${isActive ? 'opacity-100 text-accent-brown font-bold' : 'opacity-30 group-hover:opacity-100 text-muted-text'}`} />
          {isActive && (
            <span className="text-[9px] font-extrabold text-accent-brown bg-accent-cream/85 px-1.5 py-0.5 rounded uppercase font-mono">
              {order}
            </span>
          )}
        </div>
      </th>
    );
  };

  const toggleKarvyRow = (id: string) => {
    setExpandedKarvyRows(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const toggleTrailRow = (id: string) => {
    setExpandedTrailRows(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // --- FILTERING & SEARCH ARRAYS ---
  // Karvy Filtered List
  const filteredKarvySummary = useMemo(() => {
    let result = karvySummaryRows.filter(row => {
      const q = kSearch.toLowerCase().trim();
      if (kFilterInvestor && row['Investor Name'] !== kFilterInvestor) return false;
      if (kFilterFolio && row['Account No'] !== kFilterFolio) return false;
      if (kFilterScheme && row['Fund Description'] !== kFilterScheme) return false;
      if (kFilterHead && row['Brokerage Head'] !== kFilterHead) return false;
      if (kFilterDesc && row['Trxn Type'] !== kFilterDesc) return false;
      
      if (q) {
        const hay = [
          row['Investor Name'],
          row['Fund Description'],
          row['Account No'],
          row['Transaction Date'],
          row['Transaction No'],
          row['Trxn Type'],
          row['Brokerage Head']
        ].join(' ').toLowerCase();
        
        return q.split(' ').every(w => hay.includes(w));
      }
      return true;
    });

    if (kSortField) {
      result = [...result].sort((a, b) => {
        let valA = a[kSortField];
        let valB = b[kSortField];

        // Custom extraction for dates and numbers to sort properly
        if (kSortField === 'Transaction Date') {
          valA = a._date_raw;
          valB = b._date_raw;
        } else if (kSortField === 'Amount (₹)' || kSortField === 'Units' || kSortField === 'Percentage (%)' || kSortField === 'Brokerage (₹)') {
          valA = parseFloat(valA as any) || 0;
          valB = parseFloat(valB as any) || 0;
        }

        if (typeof valA === 'string' && typeof valB === 'string') {
          return kSortOrder === 'asc' 
            ? valA.localeCompare(valB) 
            : valB.localeCompare(valA);
        } else {
          const numA = Number(valA);
          const numB = Number(valB);
          return kSortOrder === 'asc' ? numA - numB : numB - numA;
        }
      });
    }

    return result;
  }, [karvySummaryRows, kSearch, kFilterInvestor, kFilterFolio, kFilterScheme, kFilterHead, kFilterDesc, kSortField, kSortOrder]);

  // Karvy Unique Dropdown lists
  const karvyInvestors = useMemo(() => {
    return [...new Set(karvySummaryRows.map(r => r['Investor Name']))].sort();
  }, [karvySummaryRows]);

  const karvySchemes = useMemo(() => {
    const subset = kFilterInvestor
      ? karvySummaryRows.filter(r => r['Investor Name'] === kFilterInvestor)
      : karvySummaryRows;
    return [...new Set(subset.map(r => r['Fund Description']))].sort();
  }, [karvySummaryRows, kFilterInvestor]);

  const karvyFolios = useMemo(() => {
    let subset = karvySummaryRows;
    if (kFilterInvestor) subset = subset.filter(r => r['Investor Name'] === kFilterInvestor);
    if (kFilterScheme) subset = subset.filter(r => r['Fund Description'] === kFilterScheme);
    return [...new Set(subset.map(r => r['Account No']))].sort();
  }, [karvySummaryRows, kFilterInvestor, kFilterScheme]);

  const karvyHeads = useMemo(() => {
    return [...new Set(karvySummaryRows.map(r => r['Brokerage Head']))].sort();
  }, [karvySummaryRows]);

  const karvyDescs = useMemo(() => {
    return [...new Set(karvySummaryRows.map(r => r['Trxn Type']))].sort();
  }, [karvySummaryRows]);


  // Trail Filtered List
  const filteredTrailSummary = useMemo(() => {
    let result = trailSummaryRows.filter(row => {
      const q = tSearch.toLowerCase().trim();
      if (tFilterType && row['Type'] !== tFilterType) return false;
      if (tFilterInvestor && row['Investor Name'] !== tFilterInvestor) return false;
      if (tFilterFolio && row['Folio'] !== tFilterFolio) return false;
      if (tFilterScheme && row['Scheme'] !== tFilterScheme) return false;

      if (q) {
        const hay = [
          row['Investor Name'],
          row['Scheme'],
          row['Folio'],
          row['Proc Date'],
          row['Trxn No'],
          row['Type'],
          row['Fee Desc']
        ].join(' ').toLowerCase();
        
        return q.split(' ').every(w => hay.includes(w));
      }
      return true;
    });

    if (tSortField) {
      result = [...result].sort((a, b) => {
        let valA = a[tSortField];
        let valB = b[tSortField];

        // Custom extraction for dates and numbers to sort properly
        if (tSortField === 'Proc Date') {
          valA = a._procdate_raw;
          valB = b._procdate_raw;
        } else if (tSortField === 'Units' || tSortField === 'Amount' || tSortField === 'Rate') {
          valA = parseFloat(valA as any) || 0;
          valB = parseFloat(valB as any) || 0;
        }

        if (typeof valA === 'string' && typeof valB === 'string') {
          return tSortOrder === 'asc' 
            ? valA.localeCompare(valB) 
            : valB.localeCompare(valA);
        } else {
          const numA = Number(valA);
          const numB = Number(valB);
          return tSortOrder === 'asc' ? numA - numB : numB - numA;
        }
      });
    }

    return result;
  }, [trailSummaryRows, tSearch, tFilterType, tFilterInvestor, tFilterFolio, tFilterScheme, tSortField, tSortOrder]);

  // Trail Unique Dropdown Lists
  const trailInvestors = useMemo(() => {
    return [...new Set(trailSummaryRows.map(r => r['Investor Name']))].sort();
  }, [trailSummaryRows]);

  const trailSchemes = useMemo(() => {
    const subset = tFilterInvestor
      ? trailSummaryRows.filter(r => r['Investor Name'] === tFilterInvestor)
      : trailSummaryRows;
    return [...new Set(subset.map(r => r['Scheme']))].sort();
  }, [trailSummaryRows, tFilterInvestor]);

  const trailFolios = useMemo(() => {
    let subset = trailSummaryRows;
    if (tFilterInvestor) subset = subset.filter(r => r['Investor Name'] === tFilterInvestor);
    if (tFilterScheme) subset = subset.filter(r => r['Scheme'] === tFilterScheme);
    return [...new Set(subset.map(r => r['Folio']))].sort();
  }, [trailSummaryRows, tFilterInvestor, tFilterScheme]);


  // PAGINATION CALCULATIONS
  const PAGE_SIZE = 50;

  const paginatedKarvy = useMemo(() => {
    const start = (kPage - 1) * PAGE_SIZE;
    return filteredKarvySummary.slice(start, start + PAGE_SIZE);
  }, [filteredKarvySummary, kPage]);

  const totalKarvyPages = Math.ceil(filteredKarvySummary.length / PAGE_SIZE) || 1;

  const paginatedTrail = useMemo(() => {
    const start = (tPage - 1) * PAGE_SIZE;
    return filteredTrailSummary.slice(start, start + PAGE_SIZE);
  }, [filteredTrailSummary, tPage]);

  const totalTrailPages = Math.ceil(filteredTrailSummary.length / PAGE_SIZE) || 1;


  // Reset pagination when filter triggers
  useEffect(() => { setKPage(1); }, [kSearch, kFilterInvestor, kFilterFolio, kFilterScheme, kFilterHead, kFilterDesc]);
  useEffect(() => { setTPage(1); }, [tSearch, tFilterType, tFilterInvestor, tFilterFolio, tFilterScheme]);


  // --- EXCEL EXPORT DISPATCHERS ---
  const downloadConsolidatedExcel = () => {
    if (activeERP === 'karvy') {
      if (!karvyCleanedRows.length) return;
      const ws_data = [karvyHeaders];
      karvyCleanedRows.forEach(row => {
        ws_data.push(karvyHeaders.map(h => row[h] !== undefined ? row[h] : ''));
      });
      
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(ws_data);
      
      // Auto-fit column widths
      ws['!cols'] = karvyHeaders.map(h => ({ wch: Math.min(Math.max(h.length + 2, 12), 40) }));
      XLSX.utils.book_append_sheet(wb, ws, 'Karvy Consolidated');

      // Append Summary Tab too
      const sumCols = ['Account No', 'Investor Name', 'Fund Description', 'Trxn Type', 'Transaction Date', 'Transaction No', 'Amount (₹)', 'Units', 'Percentage (%)', 'Brokerage (₹)', 'Brokerage Head'];
      const sum_data: (string | number)[][] = [sumCols];
      karvySummaryRows.forEach(r => {
        sum_data.push(sumCols.map(c => {
          const v = r[c as keyof KarvySummaryRow];
          if (['Percentage (%)', 'Brokerage (₹)', 'Amount (₹)', 'Units'].includes(c)) return Number(v) || 0;
          return String(v || '');
        }));
      });
      const ws_sum = XLSX.utils.aoa_to_sheet(sum_data);
      ws_sum['!cols'] = sumCols.map(c => ({ wch: Math.min(Math.max(c.length + 2, 12), 40) }));
      XLSX.utils.book_append_sheet(wb, ws_sum, 'Executive Summary');

      XLSX.writeFile(wb, `Karvy_Consolidated_ERP_${todayDateString()}.xlsx`);
    } else {
      // Trail ERP
      if (!trailCleanedRows.length) return;
      const ws_data = [trailHeaders];
      trailCleanedRows.forEach(row => {
        ws_data.push(trailHeaders.map(h => row[h] !== undefined ? row[h] : ''));
      });

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(ws_data);
      ws['!cols'] = trailHeaders.map(h => ({ wch: Math.min(Math.max(h.length + 2, 10), 35) }));
      XLSX.utils.book_append_sheet(wb, ws, 'Cleaned Slabs');

      // Append Summary Sheet
      const sumCols = ['Investor Name', 'Scheme', 'Folio', 'Proc Date', 'Trxn No', 'Type', 'Units', 'Amount', 'Rate', 'Fee Desc'];
      const sum_data: (string | number)[][] = [sumCols];
      trailSummaryRows.forEach(r => {
        sum_data.push(sumCols.map(c => {
          const v = r[c as keyof TrailERPSummaryRow];
          if (['Units', 'Amount', 'Rate'].includes(c)) return Number(v) || 0;
          return String(v || '');
        }));
      });
      const ws_sum = XLSX.utils.aoa_to_sheet(sum_data);
      ws_sum['!cols'] = sumCols.map(c => ({ wch: Math.min(Math.max(c.length + 2, 12), 40) }));
      XLSX.utils.book_append_sheet(wb, ws_sum, 'Slab Summary');

      XLSX.writeFile(wb, `Trail_Slabs_Consolidated_${todayDateString()}.xlsx`);
    }
  };

  const downloadSummaryOnlyExcel = () => {
    if (activeERP === 'karvy') {
      if (!karvySummaryRows.length) return;
      const sumCols = ['Account No', 'Investor Name', 'Fund Description', 'Trxn Type', 'Transaction Date', 'Transaction No', 'Amount (₹)', 'Units', 'Percentage (%)', 'Brokerage (₹)', 'Brokerage Head'];
      const data: (string | number)[][] = [sumCols];
      karvySummaryRows.forEach(r => {
        data.push(sumCols.map(c => {
          const v = r[c as keyof KarvySummaryRow];
          if (['Percentage (%)', 'Brokerage (₹)', 'Amount (₹)', 'Units'].includes(c)) return Number(v) || 0;
          return String(v || '');
        }));
      });
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = sumCols.map(c => ({ wch: 18 }));
      XLSX.utils.book_append_sheet(wb, ws, 'Brokerage Summary');
      XLSX.writeFile(wb, `Karvy_Summary_Only_${todayDateString()}.xlsx`);
    } else {
      if (!trailSummaryRows.length) return;
      const sumCols = ['Investor Name', 'Scheme', 'Folio', 'Proc Date', 'Trxn No', 'Type', 'Units', 'Amount', 'Rate', 'Fee Desc'];
      const data: (string | number)[][] = [sumCols];
      trailSummaryRows.forEach(r => {
        data.push(sumCols.map(c => {
          const v = r[c as keyof TrailERPSummaryRow];
          if (['Units', 'Amount', 'Rate'].includes(c)) return Number(v) || 0;
          return String(v || '');
        }));
      });
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = sumCols.map(c => ({ wch: 18 }));
      XLSX.utils.book_append_sheet(wb, ws, 'Slabs Summary');
      XLSX.writeFile(wb, `Trail_Summary_Only_${todayDateString()}.xlsx`);
    }
  };

  const todayDateString = () => {
    const d = new Date();
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  };

  // Statistical calculations
  const statsSummary = useMemo<ERPStats>(() => {
    if (activeERP === 'karvy') {
      const rawCount = karvyRawData.length;
      const cleanedCount = karvyCleanedRows.length;
      const rowsMergedCount = rawCount - cleanedCount;
      const uniqueInvestors = new Set(karvySummaryRows.map(r => r['Investor Name'])).size;
      const uniqueAccounts = new Set(karvySummaryRows.map(r => r['Account No'])).size;
      const totalBrokerageOrRate = karvySummaryRows.reduce((sum, r) => sum + (r['Brokerage (₹)'] || 0), 0);

      return { rawCount, cleanedCount, rowsMergedCount, uniqueInvestors, uniqueAccounts, totalBrokerageOrRate };
    } else if (activeERP === 'trail_erp') {
      const rawCount = trailRawData.length;
      const cleanedCount = trailCleanedRows.length;
      const rowsMergedCount = rawCount - cleanedCount;
      const uniqueInvestors = new Set(trailSummaryRows.map(r => r['Investor Name'])).size;
      const uniqueAccounts = new Set(trailSummaryRows.map(r => r['Folio'])).size;
      
      // Calculate average combined rate for statistical feedback
      const totalBrokerageOrRate = trailSummaryRows.reduce((sum, r) => sum + (r['Rate'] || 0), 0);

      return { rawCount, cleanedCount, rowsMergedCount, uniqueInvestors, uniqueAccounts, totalBrokerageOrRate };
    }
    return { rawCount: 0, cleanedCount: 0, rowsMergedCount: 0, uniqueInvestors: 0, uniqueAccounts: 0 };
  }, [activeERP, karvyRawData, karvyCleanedRows, karvySummaryRows, trailRawData, trailCleanedRows, trailSummaryRows]);

  // Clear filters
  const clearAllFilters = () => {
    if (activeERP === 'karvy') {
      setKSearch('');
      setKFilterInvestor('');
      setKFilterFolio('');
      setKFilterScheme('');
      setKFilterHead('');
      setKFilterDesc('');
      setKSortField('');
      setKSortOrder('asc');
      setExpandedKarvyRows({});
    } else {
      setTSearch('');
      setTFilterType('');
      setTFilterInvestor('');
      setTFilterFolio('');
      setTFilterScheme('');
      setTSortField('');
      setTSortOrder('asc');
      setExpandedTrailRows({});
    }
  };

  // Helper text highlight
  const highlightMatchText = (text: string, search: string) => {
    if (!search) return <span>{text}</span>;
    const parts = String(text).split(new RegExp(`(${search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi'));
    return (
      <span>
        {parts.map((part, i) => 
          part.toLowerCase() === search.toLowerCase() 
            ? <mark key={i} className="bg-amber-100 text-dark-text px-1 rounded-sm font-semibold">{part}</mark> 
            : <span key={i}>{part}</span>
        )}
      </span>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-surface-bg font-sans selection:bg-accent-brown-light selection:text-white">
      
      {/* ──────────────────────────────────────────────────────── */}
      {/* 1. DUAL GATE GATEWAY (PORTAL HOMEPAGE)                    */}
      {/* ──────────────────────────────────────────────────────── */}
      {!activeERP ? (
        <motion.div 
          key="gateway"
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="flex-1 py-12 px-6 max-w-6xl mx-auto w-full space-y-6 transition-all duration-300"
        >
          
          {/* Top Row: Left Up Logo Placeholder + Title Header Card (Bento Row) */}
          <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Logo Slot on Left Up Side */}
            <div className="md:col-span-3 bg-white border border-border-warm rounded-xl p-6 premium-shadow flex flex-col items-center justify-center text-center relative overflow-hidden group min-h-[160px]">
              <div className="absolute inset-0 bg-accent-cream/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              {/* Dashed placeholder for Logo */}
              <div className="border-2 border-dashed border-accent-brown/30 rounded-lg p-4 w-full h-full flex flex-col items-center justify-center gap-2">
                <div className="w-10 h-10 bg-accent-cream text-accent-brown rounded-full flex items-center justify-center font-bold text-lg">
                  L
                </div>
                <span className="text-[10px] font-bold text-accent-brown uppercase tracking-wider">Logo Space</span>
                <span className="text-[9px] text-muted-text">Place Your Logo Here</span>
              </div>
            </div>

            {/* Title Header Card */}
            <div className="md:col-span-9 bg-white border border-border-warm rounded-xl p-6 sm:p-8 premium-shadow relative overflow-hidden flex flex-col justify-center min-h-[160px]">
              <div className="absolute -right-16 -bottom-16 w-52 h-52 bg-accent-cream/30 rounded-full"></div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-accent-cream text-accent-brown border border-border-warm rounded-full text-[10px] font-bold tracking-wider uppercase mb-3 self-start">
                <Briefcase className="w-3 h-3" />
                Executive ERP Control Center
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-dark-text tracking-tight font-display">
                Karvy &amp; CAMS MF Brokerage Cleaner
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-muted-text max-w-2xl leading-relaxed">
                Welcome to the premium centralized portal for processing, sanitizing, and consolidating mutual fund distributor trail brokerage and rate data.
              </p>
            </div>
          </motion.div>

          {/* Quick Realtime System Info Bento Grid (Row) */}
          <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            <div className="bg-white border border-border-warm rounded-xl p-5 premium-shadow flex items-center gap-4">
              <div className="p-3 bg-accent-cream rounded-lg text-accent-brown">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-muted-text font-bold uppercase tracking-wider">System Reference Time</p>
                <p className="text-sm font-bold text-dark-text font-mono mt-0.5">{localTime} UTC</p>
              </div>
            </div>

            <div className="bg-white border border-border-warm rounded-xl p-5 premium-shadow flex items-center gap-4">
              <div className="p-3 bg-accent-cream rounded-lg text-accent-brown">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-muted-text font-bold uppercase tracking-wider">Active Secure Session</p>
                <p className="text-sm font-bold text-dark-text mt-0.5 truncate max-w-[200px]">{userEmail}</p>
              </div>
            </div>

            <div className="bg-white border border-border-warm rounded-xl p-5 premium-shadow flex items-center gap-4">
              <div className="p-3 bg-green-50 text-green-700 rounded-lg border border-green-100">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-muted-text font-bold uppercase tracking-wider">Data Processing Mode</p>
                <p className="text-sm font-bold text-green-800 mt-0.5">100% Client-Side Local sandbox</p>
              </div>
            </div>

          </motion.div>

          {/* Dual Gate Grid (Bento Row) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Gate 1: Karvy */}
            <motion.div 
              variants={itemVariants}
              onClick={() => selectERP('karvy')}
              className="group relative bg-white border border-border-warm rounded-xl p-8 premium-shadow hover:premium-shadow-lg transition-all duration-300 cursor-pointer hover:border-accent-brown flex flex-col justify-between min-h-[300px]"
            >
              <div>
                <div className="absolute top-6 right-6 text-[10px] font-bold px-2.5 py-1 rounded bg-accent-cream text-accent-brown uppercase tracking-wider group-hover:bg-accent-brown group-hover:text-white transition-colors border border-border-warm">
                  ERP 1
                </div>
                <div className="w-12 h-12 bg-accent-cream rounded-lg flex items-center justify-center text-accent-brown mb-6 group-hover:scale-105 transition-transform duration-300">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-dark-text group-hover:text-accent-brown transition-colors">
                  Karvy MF Brokerage Cleaner
                </h3>
                <p className="mt-3 text-xs sm:text-sm text-muted-text leading-relaxed">
                  Aggregates separate transaction rows sharing identical <strong>Transaction Numbers</strong>. Sums percentages and brokerage rates, and consolidates multiple trail fee heads (e.g. Addtrail + LongTermTrailFee) into unified structures sorted by FIFO sequence.
                </p>
              </div>
              <div className="mt-8 inline-flex items-center gap-2 text-xs font-bold text-accent-brown group-hover:translate-x-1 transition-transform">
                Open Workspace <ArrowRight className="w-4 h-4" />
              </div>
            </motion.div>

            {/* Gate 2: CAMS MF Brokerage Cleaner */}
            <motion.div 
              variants={itemVariants}
              onClick={() => selectERP('trail_erp')}
              className="group relative bg-white border border-border-warm rounded-xl p-8 premium-shadow hover:premium-shadow-lg transition-all duration-300 cursor-pointer hover:border-accent-brown flex flex-col justify-between min-h-[300px]"
            >
              <div>
                <div className="absolute top-6 right-6 text-[10px] font-bold px-2.5 py-1 rounded bg-accent-cream text-accent-brown uppercase tracking-wider group-hover:bg-accent-brown group-hover:text-white transition-colors border border-border-warm">
                  ERP 2
                </div>
                <div className="w-12 h-12 bg-accent-cream rounded-lg flex items-center justify-center text-accent-brown mb-6 group-hover:scale-105 transition-transform duration-300">
                  <Database className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-dark-text group-hover:text-accent-brown transition-colors">
                  CAMS MF Brokerage Cleaner
                </h3>
                <p className="mt-3 text-xs sm:text-sm text-muted-text leading-relaxed">
                  Eliminates raw file duplicates and merges sub-lot brokerage rate slabs having matching <strong>Folio, Investor, Scheme, Transaction No, and Proc Dates</strong>. Automatically sums rate tiers and builds pristine, auditable summary sheets.
                </p>
              </div>
              <div className="mt-8 inline-flex items-center gap-2 text-xs font-bold text-accent-brown group-hover:translate-x-1 transition-transform">
                Open Workspace <ArrowRight className="w-4 h-4" />
              </div>
            </motion.div>

          </div>

          {/* Security Banner Card (Bento Row) */}
          <motion.div variants={itemVariants} className="bg-accent-cream/40 border border-border-warm rounded-xl p-6 text-center text-xs text-muted-text leading-relaxed premium-shadow">
            <span className="font-bold text-dark-text uppercase tracking-wider text-[10px] mr-1 bg-accent-cream px-1.5 py-0.5 rounded border border-border-warm inline-block">Security Assurance:</span> To maximize compliance and client data privacy, all file ingestion, column analysis, mathematical operations, and spreadsheet exports take place inside your browser’s isolated JavaScript scope. No server transactions are performed.
          </motion.div>

        </motion.div>
      ) : (
        
        /* ──────────────────────────────────────────────────────── */
        /* 2. WORKSPACE INTERFACE (SELECTED APP ENVIRONMENT)        */
        /* ──────────────────────────────────────────────────────── */
        <div className="flex-1 flex flex-col md:flex-row">
          
          {/* NAVIGATION SIDEBAR (LEFT) */}
          <aside className="w-full md:w-[260px] bg-surface-bg border-b md:border-b-0 md:border-r border-border-warm flex flex-col shrink-0">
            
            {/* Active ERP Identity Badge */}
            <div className="px-8 pb-8 pt-6 border-b border-border-warm bg-accent-cream/20">
              <div className="text-xl font-bold tracking-tight text-dark-text flex items-center gap-1">
                EXECUTIVE<span className="text-accent-brown">ERP</span>
              </div>
              <div className="flex items-center gap-1.5 mt-2">
                <span className="w-1.5 h-1.5 rounded-full bg-accent-brown animate-pulse"></span>
                <span className="text-[10px] font-bold text-accent-brown tracking-wider uppercase">
                  {activeERP === 'karvy' ? 'Portal 1: Karvy' : 'Portal 2: CAMS MF Brokerage Cleaner'}
                </span>
              </div>
            </div>

            {/* Navigation Menu */}
            <nav className="flex-1 py-6 space-y-1">
              <button 
                onClick={() => setActiveSubPage('overview')}
                className={`w-full flex items-center gap-3 py-3 px-8 text-sm transition-all duration-150 text-left ${
                  activeSubPage === 'overview' 
                    ? 'text-accent-brown bg-accent-brown/8 border-r-3 border-accent-brown font-semibold' 
                    : 'text-muted-text hover:text-accent-brown hover:bg-accent-brown/4 font-medium'
                }`}
              >
                <Info className="w-4 h-4 shrink-0" />
                <span>Overview &amp; Rules</span>
              </button>

              <button 
                onClick={() => setActiveSubPage('cleaner')}
                className={`w-full flex items-center gap-3 py-3 px-8 text-sm transition-all duration-150 text-left relative ${
                  activeSubPage === 'cleaner' 
                    ? 'text-accent-brown bg-accent-brown/8 border-r-3 border-accent-brown font-semibold' 
                    : 'text-muted-text hover:text-accent-brown hover:bg-accent-brown/4 font-medium'
                }`}
              >
                <Upload className="w-4 h-4 shrink-0" />
                <span>Import &amp; Process</span>
                {((activeERP === 'karvy' && karvyRawData.length > 0) || (activeERP === 'trail_erp' && trailRawData.length > 0)) && (
                  <span className="absolute right-8 top-4 w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                )}
              </button>

              <button 
                onClick={() => setActiveSubPage('database')}
                className={`w-full flex items-center justify-between py-3 px-8 text-sm transition-all duration-150 text-left ${
                  activeSubPage === 'database' 
                    ? 'text-accent-brown bg-accent-brown/8 border-r-3 border-accent-brown font-semibold' 
                    : 'text-muted-text hover:text-accent-brown hover:bg-accent-brown/4 font-medium'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Grid className="w-4 h-4 shrink-0" />
                  <span>Dynamic Database</span>
                </div>
                {((activeERP === 'karvy' && karvySummaryRows.length > 0) || (activeERP === 'trail_erp' && trailSummaryRows.length > 0)) && (
                  <span className="text-[10px] bg-white text-accent-brown font-mono px-1.5 py-0.5 rounded border border-border-warm font-bold">
                    {activeERP === 'karvy' ? karvySummaryRows.length : trailSummaryRows.length}
                  </span>
                )}
              </button>

              <button 
                onClick={() => setActiveSubPage('analytics')}
                className={`w-full flex items-center gap-3 py-3 px-8 text-sm transition-all duration-150 text-left ${
                  activeSubPage === 'analytics' 
                    ? 'text-accent-brown bg-accent-brown/8 border-r-3 border-accent-brown font-semibold' 
                    : 'text-muted-text hover:text-accent-brown hover:bg-accent-brown/4 font-medium'
                }`}
              >
                <TrendingUp className="w-4 h-4 shrink-0" />
                <span>Analytics &amp; Stats</span>
              </button>
            </nav>

            {/* Quick Demo Workspace Box */}
            <div className="px-6 py-4 mx-4 mb-4 bg-white border border-border-warm rounded-xl premium-shadow">
              <h4 className="text-xs font-bold text-dark-text uppercase tracking-wide mb-1 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Instant Sandbox
              </h4>
              <p className="text-[11px] text-muted-text leading-relaxed mb-2.5">
                Populate this platform with simulated trial ledger data.
              </p>
              <button 
                onClick={loadDemoData}
                className="w-full bg-accent-cream hover:bg-accent-brown hover:text-white text-accent-brown font-bold text-xs py-2 px-3 rounded-lg border border-border-warm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Load Demo Dataset
              </button>
            </div>

            {/* Local System Context Badge */}
            <div className="px-6 pb-6 pt-2">
              <div className="bg-accent-brown text-white rounded-xl p-4 premium-shadow">
                <div className="text-[10px] uppercase font-bold tracking-wider opacity-80 mb-0.5">Secure Context</div>
                <div className="text-xs font-bold font-mono truncate">{userEmail}</div>
                <div className="text-[10px] opacity-70 mt-1 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block animate-pulse"></span>
                  Active local sandbox
                </div>
              </div>
            </div>

            {/* Return Portal Button */}
            <div className="p-4 border-t border-border-warm bg-accent-cream/20">
              <button 
                onClick={() => selectERP(null)}
                className="w-full flex items-center justify-center gap-2 bg-white hover:bg-red-50 text-dark-text hover:text-red-700 font-bold text-xs py-2.5 px-3 rounded-lg border border-border-warm transition-colors premium-shadow cursor-pointer"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                Exit Workspace
              </button>
            </div>

          </aside>

          {/* WORKSPACE CONTENT FIELD (RIGHT) */}
          <main className="flex-1 bg-white flex flex-col min-w-0">
            
            {/* GLOBAL WORKSPACE HEADER */}
            <header className="h-[72px] px-8 bg-white border-b border-border-warm flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="font-semibold text-base text-dark-text">
                  {activeERP === 'karvy' ? 'ERP Tool 1: Karvy' : 'ERP Tool 2: CAMS MF Brokerage Cleaner'}
                </div>
                <div className="w-px h-6 bg-border-warm"></div>
                <div className="text-muted-text text-sm hidden sm:block">Unified Workspace</div>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Switcher ERP Select */}
                <div className="flex items-center gap-1 bg-surface-bg border border-border-warm rounded-lg px-2.5 py-1.5">
                  <select 
                    value={activeERP || ''} 
                    onChange={(e) => selectERP(e.target.value as ERPType)}
                    className="bg-transparent text-xs font-semibold text-dark-text focus:outline-none cursor-pointer"
                  >
                    <option value="karvy">ERP Tool 1: Karvy</option>
                    <option value="trail_erp">ERP Tool 2: CAMS</option>
                  </select>
                </div>
                
                {/* User Initials Badge */}
                <div className="w-9 h-9 bg-accent-cream border border-border-warm rounded-full flex items-center justify-center font-bold text-xs text-accent-brown" title={userEmail}>
                  JD
                </div>
              </div>
            </header>

            {/* DYNAMIC SUBPAGE CONTAINER */}
            <div className="flex-1 overflow-y-auto p-6 max-w-7xl w-full mx-auto space-y-6">
              
              {/* PAGE 1: OVERVIEW & PROCESSING RULES */}
              {activeSubPage === 'overview' && (
                <motion.div 
                  key="overview"
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-1 md:grid-cols-12 gap-5"
                >
                  
                  {/* Executive Brief Card */}
                  <motion.div variants={itemVariants} className="md:col-span-12 bg-accent-cream border border-border-warm rounded-xl p-6 premium-shadow relative overflow-hidden">
                    <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-border-warm/20 rounded-full"></div>
                    <h2 className="text-xl font-bold text-dark-text mb-2 tracking-tight">
                      Workspace Mission &amp; Processing Rules
                    </h2>
                    <p className="text-dark-text/90 leading-relaxed text-xs sm:text-sm max-w-3xl">
                      Mutual Fund brokerages issue large tables with separate line entries containing segmented trail fee heads. Standard databases struggle with this tier fragmentation. This integrated solution provides two robust utilities designed to merge rates, deduplicate records, sum parameters, and establish unified executive ledgers.
                    </p>
                  </motion.div>

                  {/* Processing Formula Card 1 */}
                  <motion.div variants={itemVariants} className="md:col-span-6 bg-white border border-border-warm rounded-xl p-5 premium-shadow flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-dark-text mb-4 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-accent-brown"></span>
                        Key Aggregation Logic
                      </h3>
                      <ul className="space-y-3 text-xs text-muted-text">
                        {activeERP === 'karvy' ? (
                          <>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 1:</span>
                              Locates any records sharing an identical <strong>Transaction Number</strong>. These rows are collapsed into a single unified row.
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 2:</span>
                              Sums all numeric <strong>Percentages (%)</strong> and <strong>Brokerage (in Rs.)</strong> fields to combine fee heads.
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 3:</span>
                              If <strong>Units</strong> values differ across combined lines, the engine sums them; otherwise, it retains the identical value.
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 4:</span>
                              Concatenates distinct Brokerage heads using a ` + ` separator (e.g., <em>"LongTermTrailFee + Addtrail"</em>).
                            </li>
                          </>
                        ) : (
                          <>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 1:</span>
                              Purges exact, redundant duplicate rows from the spreadsheet to prevent double counting.
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 2:</span>
                              Identifies separate rows matching exactly on key identifiers: <strong>Folio + Investor Name + Scheme + Transaction No + Procdate + Units + Amount</strong>.
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 3:</span>
                              Sums the distinct rates to form a single master rate slab (e.g. 1.00% trail + 0.25% add incentive = 1.25%).
                            </li>
                            <li className="flex gap-2 leading-relaxed">
                              <span className="font-bold text-accent-brown shrink-0">Step 4:</span>
                              Aggregates and joins corresponding fee descriptions with a pipe ` | ` divider.
                            </li>
                          </>
                        )}
                      </ul>
                    </div>
                  </motion.div>

                  {/* Processing Formula Card 2 */}
                  <motion.div variants={itemVariants} className="md:col-span-6 bg-white border border-border-warm rounded-xl p-5 premium-shadow flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-dark-text mb-4 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-accent-brown-light"></span>
                        Sorting &amp; Auditing Standards
                      </h3>
                      <ul className="space-y-3.5 text-xs text-muted-text">
                        <li className="flex gap-2 leading-relaxed">
                          <span className="font-bold text-accent-brown shrink-0">Chronology:</span>
                          Employs rigorous **FIFO (First In First Out)** sorting. Sorting orders records oldest-to-newest by processing date first.
                        </li>
                        <li className="flex gap-2 leading-relaxed">
                          <span className="font-bold text-accent-brown shrink-0">Traceability:</span>
                          Saves original columns and maps raw headers case-insensitively, keeping both native and consolidated structures in the workspace.
                        </li>
                        <li className="flex gap-2 leading-relaxed">
                          <span className="font-bold text-accent-brown shrink-0">Export Formats:</span>
                          Supports two exports: <strong>Cleaned Data Workbook</strong> (fully expanded) or a polished <strong>Executive Summary Worksheet</strong>.
                        </li>
                      </ul>
                    </div>
                  </motion.div>

                  {/* Visual Example Diagram Card */}
                  <motion.div variants={itemVariants} className="md:col-span-12 bg-white border border-border-warm rounded-xl p-6 premium-shadow">
                    <h3 className="text-sm font-bold text-dark-text uppercase tracking-wide mb-4">
                      Example Consolidation Lifecycle
                    </h3>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-center">
                      
                      {/* Before State */}
                      <div className="bg-surface-bg border border-border-warm rounded-lg p-4">
                        <p className="text-[10px] font-bold text-accent-brown uppercase tracking-wider mb-2">Fragmented Input Slabs</p>
                        <div className="space-y-2 font-mono text-[10px] text-muted-text">
                          <div className="p-2 bg-red-50/50 rounded border border-red-100">
                            <strong>Trxn Number:</strong> 220199<br/>
                            <strong>Brokerage Head:</strong> Addtrail<br/>
                            <strong>Rate:</strong> 0.25% | <strong>Fee:</strong> ₹125
                          </div>
                          <div className="p-2 bg-red-50/50 rounded border border-red-100">
                            <strong>Trxn Number:</strong> 220199<br/>
                            <strong>Brokerage Head:</strong> LongTermTrail<br/>
                            <strong>Rate:</strong> 0.75% | <strong>Fee:</strong> ₹375
                          </div>
                        </div>
                      </div>

                      {/* Direction Icon */}
                      <div className="text-center py-2 lg:py-0">
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-accent-cream rounded-full text-xs font-bold text-accent-brown border border-border-warm premium-shadow">
                          ERP Parser Engine <ArrowRight className="w-4 h-4 animate-pulse" />
                        </div>
                      </div>

                      {/* Cleaned Result */}
                      <div className="bg-green-50/20 border border-green-200 rounded-lg p-4">
                        <p className="text-[10px] font-bold text-green-700 uppercase tracking-wider mb-2">Pristine Executive Ledger Row</p>
                        <div className="p-2 bg-green-50/75 rounded border border-green-100 font-mono text-[10px] text-green-900 space-y-1">
                          <strong>Trxn Number:</strong> 220199<br/>
                          <strong>Heads Combined:</strong> Addtrail + LongTermTrail<br/>
                          <strong>Rate Combined:</strong> <span className="font-bold text-green-700">1.00%</span><br/>
                          <strong>Total Brokerage:</strong> <span className="font-bold text-green-700">₹500.00</span>
                        </div>
                      </div>

                    </div>

                    <div className="mt-6 flex justify-end">
                      <button 
                        onClick={() => setActiveSubPage('cleaner')}
                        className="bg-accent-brown hover:bg-accent-brown-hover text-white font-bold text-xs py-2.5 px-4 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
                      >
                        Proceed to Import Workspace <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>

                  </motion.div>

                </motion.div>
              )}

              {/* PAGE 2: IMPORT, DEDUP & CLEANSE WORKSPACE */}
              {activeSubPage === 'cleaner' && (
                <motion.div 
                  key="cleaner"
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-1 md:grid-cols-12 gap-5"
                >
                  
                  {/* Draggable Zone Container */}
                  <motion.div variants={itemVariants} className={`${logs.length > 0 ? 'md:col-span-7' : 'md:col-span-12'} bg-white border border-border-warm rounded-xl p-6 premium-shadow flex flex-col justify-between`}>
                    <div>
                      <h3 className="text-sm font-bold text-dark-text mb-4">
                        File Ingestion Sandbox
                      </h3>

                      <div 
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        className={`border-2 border-dashed rounded-xl p-10 text-center transition-all ${
                          isDragging ? 'border-accent-brown bg-accent-cream/50' : 'border-border-warm bg-surface-bg'
                        } ${isLoading ? 'opacity-70 pointer-events-none' : ''}`}
                      >
                        <div className="max-w-md mx-auto flex flex-col items-center">
                          <div className="w-14 h-14 bg-white border border-border-warm rounded-full flex items-center justify-center text-accent-brown mb-4 premium-shadow">
                            <Upload className="w-6 h-6" />
                          </div>
                          
                          <h4 className="text-sm font-bold text-dark-text">
                            Drag and Drop Brokerage Excel Spreadsheet
                          </h4>
                          <p className="text-[11px] text-muted-text mt-1.5 max-w-xs leading-relaxed">
                            Supports <strong>.xlsx</strong> and <strong>.xls</strong> workbooks generated by mutual fund distribution houses.
                          </p>

                          <div className="mt-6 flex flex-col sm:flex-row gap-2.5 w-full justify-center">
                            <button 
                              type="button"
                              onClick={() => document.getElementById('actualFileInput')?.click()}
                              className="bg-accent-brown hover:bg-accent-brown-hover text-white font-bold text-xs py-2 px-4 rounded-lg transition-all premium-shadow cursor-pointer"
                            >
                              Browse Files Locally
                            </button>
                            
                            <button 
                              type="button"
                              onClick={loadDemoData}
                              className="bg-white hover:bg-accent-cream text-dark-text hover:text-accent-brown font-bold text-xs py-2 px-4 rounded-lg border border-border-warm transition-all premium-shadow cursor-pointer"
                            >
                              Test with Simulated Data
                            </button>
                          </div>

                          <input 
                            type="file" 
                            id="actualFileInput"
                            accept=".xlsx, .xls"
                            onChange={handleFileChange}
                            className="hidden" 
                          />
                        </div>
                      </div>
                    </div>

                    {/* Progress Indicator */}
                    {isLoading && (
                      <div className="mt-6 space-y-2">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-semibold text-accent-brown font-mono">{progressMsg}</span>
                          <span className="font-bold text-dark-text">{progressPercent}%</span>
                        </div>
                        <div className="w-full h-2 bg-accent-cream rounded-full overflow-hidden border border-border-warm">
                          <div 
                            className="h-full bg-accent-brown transition-all duration-300"
                            style={{ width: `${progressPercent}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                  </motion.div>

                  {/* Ingestion Console Logs Terminal */}
                  {logs.length > 0 && (
                    <motion.div variants={itemVariants} className="md:col-span-5 bg-white border border-border-warm rounded-xl p-5 premium-shadow flex flex-col h-full min-h-[350px]">
                      <h4 className="text-xs font-bold text-dark-text uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <Sliders className="w-3.5 h-3.5 text-accent-brown" />
                        Execution History Logs
                      </h4>
                      
                      <div className="bg-dark-text rounded-lg p-4 font-mono text-[11px] text-accent-cream space-y-2 flex-1 overflow-y-auto custom-scrollbar shadow-inner max-h-[320px]">
                        {logs.map((log, idx) => (
                          <div key={idx} className="flex gap-2 leading-relaxed">
                            <span className="text-muted-text select-none">{idx + 1}.</span>
                            <span className={
                              log.type === 'ok' ? 'text-green-400' :
                              log.type === 'warn' ? 'text-amber-400' : 'text-blue-300'
                            }>
                              [{log.type.toUpperCase()}] {log.text}
                            </span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Active Upload Feedback Card */}
                  {fileName && (
                    <motion.div variants={itemVariants} className="md:col-span-12 bg-white border border-border-warm rounded-xl p-5 premium-shadow flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="p-2 bg-green-50 text-green-700 rounded-lg border border-green-100">
                          <CheckCircle className="w-5 h-5" />
                        </span>
                        <div>
                          <p className="text-[10px] text-muted-text font-bold uppercase tracking-wider">Processed File</p>
                          <h4 className="text-sm font-bold text-dark-text mt-0.5">{fileName}</h4>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button 
                          onClick={() => setActiveSubPage('database')}
                          className="bg-accent-cream hover:bg-accent-brown hover:text-white text-accent-brown text-xs font-bold px-4 py-2.5 rounded-lg border border-border-warm transition-all cursor-pointer"
                        >
                          View Database Grid
                        </button>
                        <button 
                          onClick={resetCurrentToolState}
                          className="text-red-700 hover:bg-red-50 p-2.5 rounded-lg transition-colors border border-transparent hover:border-red-100 cursor-pointer"
                          title="Purge Current Data"
                        >
                          <Trash2 className="w-4.5 h-4.5" />
                        </button>
                      </div>
                    </motion.div>
                  )}

                </motion.div>
              )}

              {/* PAGE 3: INTERACTIVE DATABASE DATAGRID */}
              {activeSubPage === 'database' && (
                <motion.div 
                  key="database"
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="space-y-6"
                >
                  
                  {/* Validation check */}
                  {((activeERP === 'karvy' && !karvySummaryRows.length) || (activeERP === 'trail_erp' && !trailSummaryRows.length)) ? (
                    <motion.div variants={itemVariants} className="bg-white border border-border-warm rounded-xl p-12 text-center premium-shadow max-w-2xl mx-auto">
                      <div className="w-14 h-14 bg-accent-cream rounded-full flex items-center justify-center text-accent-brown mx-auto mb-4">
                        <Database className="w-6 h-6" />
                      </div>
                      <h3 className="text-lg font-bold text-dark-text">No Cleaned Ledger Present</h3>
                      <p className="text-xs text-muted-text mt-1.5 max-w-md mx-auto">
                        Please upload your raw mutual fund brokerage spreadsheets or click below to populate the workspace with test datasets instantly.
                      </p>
                      <div className="mt-6 flex justify-center gap-3">
                        <button 
                          onClick={() => setActiveSubPage('cleaner')}
                          className="bg-accent-brown hover:bg-accent-brown-hover text-white font-bold text-xs py-2.5 px-5 rounded-lg transition-all cursor-pointer"
                        >
                          Go to Import Page
                        </button>
                        <button 
                          onClick={loadDemoData}
                          className="bg-accent-cream hover:bg-accent-brown hover:text-white text-accent-brown font-bold text-xs py-2.5 px-5 rounded-lg border border-border-warm transition-all cursor-pointer"
                        >
                          Load Demo Dataset
                        </button>
                      </div>
                    </motion.div>
                  ) : (
                    
                    /* Dynamic Ledger Content */
                    <div className="space-y-6">
                      
                      {/* Interactive Filter Control Center */}
                      <motion.div variants={itemVariants} className="bg-white border border-border-warm rounded-xl p-5 premium-shadow space-y-4">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                          <div>
                            <h3 className="text-sm font-bold text-dark-text flex items-center gap-2">
                              <Filter className="w-4 h-4 text-accent-brown" />
                              Interactive Ledger Filtering
                            </h3>
                            <p className="text-xs text-muted-text mt-0.5">Filter records by client names, account structures, fee types, and specific transaction indices.</p>
                          </div>

                          {/* Quick Filter Purge */}
                          <button 
                            onClick={clearAllFilters}
                            className="self-start lg:self-auto text-xs font-bold text-accent-brown hover:text-accent-brown-hover flex items-center gap-1.5 cursor-pointer"
                          >
                            Reset Active Filters
                          </button>
                        </div>

                        {/* Search Input and Dynamic Select Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                          
                          {/* Search bar */}
                          <div className="relative lg:col-span-2">
                            <span className="absolute left-3 top-2.5 text-muted-text">
                              <Search className="w-4 h-4" />
                            </span>
                            <input 
                              type="text"
                              value={activeERP === 'karvy' ? kSearch : tSearch}
                              onChange={(e) => {
                                if (activeERP === 'karvy') setKSearch(e.target.value);
                                else setTSearch(e.target.value);
                              }}
                              placeholder="Search anything dynamically..."
                              className="w-full pl-9 pr-4 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-medium text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown transition-all"
                            />
                          </div>

                          {activeERP === 'karvy' ? (
                            <>
                              {/* Investor Dropdown */}
                              <div>
                                <select 
                                  value={kFilterInvestor}
                                  onChange={(e) => {
                                    setKFilterInvestor(e.target.value);
                                    setKFilterFolio(''); // clear dependent folio
                                    setKFilterScheme(''); // clear dependent scheme
                                  }}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Investors ({karvyInvestors.length})</option>
                                  {karvyInvestors.map((inv, idx) => (
                                    <option key={idx} value={inv}>{inv}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Scheme Dropdown */}
                              <div>
                                <select 
                                  value={kFilterScheme}
                                  onChange={(e) => {
                                    setKFilterScheme(e.target.value);
                                    setKFilterFolio(''); // clear dependent folio
                                  }}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Schemes ({karvySchemes.length})</option>
                                  {karvySchemes.map((sch, idx) => (
                                    <option key={idx} value={sch}>{sch}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Folio Dropdown */}
                              <div>
                                <select 
                                  value={kFilterFolio}
                                  onChange={(e) => setKFilterFolio(e.target.value)}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Accounts ({karvyFolios.length})</option>
                                  {karvyFolios.map((fol, idx) => (
                                    <option key={idx} value={fol}>{fol}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Brokerage Head Dropdown */}
                              <div>
                                <select 
                                  value={kFilterHead}
                                  onChange={(e) => setKFilterHead(e.target.value)}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Brokerage Heads ({karvyHeads.length})</option>
                                  {karvyHeads.map((head, idx) => (
                                    <option key={idx} value={head}>{head}</option>
                                  ))}
                                </select>
                              </div>
                            </>
                          ) : (
                            <>
                              {/* Investor Dropdown */}
                              <div>
                                <select 
                                  value={tFilterInvestor}
                                  onChange={(e) => {
                                    setTFilterInvestor(e.target.value);
                                    setTFilterFolio('');
                                    setTFilterScheme('');
                                  }}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Investors ({trailInvestors.length})</option>
                                  {trailInvestors.map((inv, idx) => (
                                    <option key={idx} value={inv}>{inv}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Scheme Dropdown */}
                              <div>
                                <select 
                                  value={tFilterScheme}
                                  onChange={(e) => {
                                    setTFilterScheme(e.target.value);
                                    setTFilterFolio('');
                                  }}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Schemes ({trailSchemes.length})</option>
                                  {trailSchemes.map((sch, idx) => (
                                    <option key={idx} value={sch}>{sch}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Folio Dropdown */}
                              <div>
                                <select 
                                  value={tFilterFolio}
                                  onChange={(e) => setTFilterFolio(e.target.value)}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Folios ({trailFolios.length})</option>
                                  {trailFolios.map((fol, idx) => (
                                    <option key={idx} value={fol}>{fol}</option>
                                  ))}
                                </select>
                              </div>

                              {/* Type Select */}
                              <div>
                                <select 
                                  value={tFilterType}
                                  onChange={(e) => setTFilterType(e.target.value)}
                                  className="w-full px-3 py-2 bg-surface-bg border border-border-warm rounded-lg text-xs font-bold text-dark-text focus:outline-none focus:border-accent-brown focus:ring-1 focus:ring-accent-brown cursor-pointer"
                                >
                                  <option value="">All Types</option>
                                  <option value="P">P — Purchase</option>
                                  <option value="DR">DR — Debit</option>
                                  <option value="TI">TI — Transfer In</option>
                                  <option value="SI">SI — Systematic</option>
                                </select>
                              </div>
                            </>
                          )}

                        </div>

                      </motion.div>

                      {/* Export Header & Feedback */}
                      <motion.div variants={itemVariants} className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 bg-surface-bg border border-border-warm rounded-xl p-4">
                        <div className="text-xs text-muted-text font-medium">
                          Found <strong className="text-dark-text">{activeERP === 'karvy' ? filteredKarvySummary.length : filteredTrailSummary.length}</strong> matching entries out of <strong className="text-dark-text">{activeERP === 'karvy' ? karvySummaryRows.length : trailSummaryRows.length}</strong> total consolidated rows.
                        </div>
                        
                        {/* Download buttons */}
                        <div className="flex flex-wrap gap-2">
                          <button 
                            onClick={downloadConsolidatedExcel}
                            className="bg-accent-brown hover:bg-accent-brown-hover text-white text-xs font-bold py-2 px-3.5 rounded-lg flex items-center gap-1.5 transition-colors premium-shadow cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                            Download Expanded Book
                          </button>
                          <button 
                            onClick={downloadSummaryOnlyExcel}
                            className="bg-white hover:bg-accent-cream text-dark-text hover:text-accent-brown text-xs font-bold py-2 px-3.5 border border-border-warm rounded-lg flex items-center gap-1.5 transition-colors premium-shadow cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                            Download Summary Sheet
                          </button>
                        </div>
                      </motion.div>

                      {/* DATAGRID TABLE */}
                      <motion.div variants={itemVariants} className="bg-white border border-border-warm rounded-xl overflow-hidden premium-shadow">
                        <div className="overflow-x-auto custom-scrollbar">
                          
                           {activeERP === 'karvy' ? (
                            /* ── Karvy table ── */
                            <table className="w-full text-left border-collapse text-xs">
                              <thead>
                                <tr className="bg-accent-cream/50 border-b border-border-warm text-muted-text font-bold text-[11px] uppercase tracking-wider">
                                  <th className="p-4 w-12 bg-accent-cream/50"></th>
                                  {renderSortableHeader("Account No", "Account No", "karvy")}
                                  {renderSortableHeader("Investor Name", "Investor Name", "karvy")}
                                  {renderSortableHeader("Fund Description", "Fund Description", "karvy")}
                                  {renderSortableHeader("Trxn Type", "Trxn Type", "karvy")}
                                  {renderSortableHeader("Trxn Date", "Transaction Date", "karvy")}
                                  {renderSortableHeader("Trxn No", "Transaction No", "karvy")}
                                  {renderSortableHeader("Amount (₹)", "Amount (₹)", "karvy", true)}
                                  {renderSortableHeader("Units", "Units", "karvy", true)}
                                  {renderSortableHeader("Rate (%)", "Percentage (%)", "karvy", true, "bg-accent-cream/60 text-accent-brown border-l border-r border-border-warm/40 font-extrabold")}
                                  {renderSortableHeader("Brokerage (₹)", "Brokerage (₹)", "karvy", true, "bg-amber-50 text-amber-800 border-r border-border-warm/40 font-extrabold")}
                                  {renderSortableHeader("Brokerage Head", "Brokerage Head", "karvy")}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border-warm">
                                {paginatedKarvy.map((row, idx) => {
                                  const hasMerged = row._mergedRows && row._mergedRows.length > 1;
                                  const isExpanded = !!expandedKarvyRows[row['Transaction No'] + '_' + idx];
                                  return (
                                    <React.Fragment key={idx}>
                                      <tr className="hover:bg-accent-cream/20 transition-colors">
                                        <td className="p-4 text-center w-12">
                                          {hasMerged ? (
                                            <button 
                                              onClick={() => toggleKarvyRow(row['Transaction No'] + '_' + idx)}
                                              className="p-1 hover:bg-accent-cream/80 text-accent-brown rounded transition-colors"
                                              title="View combined transactions"
                                            >
                                              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                                            </button>
                                          ) : (
                                            <span className="text-muted-text/30 font-mono text-[10px]">—</span>
                                          )}
                                        </td>
                                        <td className="p-4 font-mono font-medium text-dark-text">{highlightMatchText(row['Account No'], kSearch)}</td>
                                        <td className="p-4 font-semibold text-dark-text">{highlightMatchText(row['Investor Name'], kSearch)}</td>
                                        <td className="p-4 text-muted-text font-medium">{highlightMatchText(row['Fund Description'], kSearch)}</td>
                                        <td className="p-4 text-muted-text font-medium">{row['Trxn Type']}</td>
                                        <td className="p-4 font-mono text-muted-text">{row['Transaction Date']}</td>
                                        <td className="p-4 font-mono text-muted-text">{highlightMatchText(row['Transaction No'], kSearch)}</td>
                                        <td className="p-4 font-mono text-right font-medium text-dark-text">{fmtNum(row['Amount (₹)'])}</td>
                                        <td className="p-4 font-mono text-right font-medium text-dark-text">{row['Units']}</td>
                                        <td className="p-4 font-mono text-right font-bold text-accent-brown bg-accent-cream/15 border-l border-r border-border-warm/40">{row['Percentage (%)'].toFixed(4)}%</td>
                                        <td className="p-4 font-mono text-right font-extrabold text-amber-900 bg-amber-50/40 border-r border-border-warm/40">₹{fmtNum(row['Brokerage (₹)'])}</td>
                                        <td className="p-4">
                                          <span className={`inline-block px-2.5 py-1 rounded text-[10px] font-extrabold ${row['Brokerage Head'].includes('+') ? 'bg-amber-100 text-amber-800 border border-amber-200' : 'bg-accent-cream text-accent-brown border border-border-warm'}`}>
                                            {row['Brokerage Head']}
                                          </span>
                                        </td>
                                      </tr>
                                      {isExpanded && (
                                        <tr className="bg-amber-50/15">
                                          <td colSpan={12} className="p-4 border-b border-border-warm/80">
                                            <div className="bg-white/85 border border-border-warm/80 rounded-lg p-4 shadow-sm space-y-3">
                                              <div className="flex items-center justify-between">
                                                <h4 className="font-display font-extrabold text-amber-800 flex items-center gap-1.5 text-xs">
                                                  <Sparkles className="w-4 h-4 text-amber-600 animate-pulse" />
                                                  Consolidated Entry Breakdown ({row._mergedRows?.length} Rows Merged)
                                                </h4>
                                                <span className="text-[10px] text-muted-text font-bold">
                                                  Grouped by Trxn No: <strong className="font-mono text-dark-text">{row['Transaction No']}</strong>
                                                </span>
                                              </div>
                                              
                                              <table className="w-full text-left border-collapse text-[11px] bg-surface-bg border border-border-warm/60 rounded overflow-hidden">
                                                <thead>
                                                  <tr className="bg-accent-cream/40 border-b border-border-warm text-muted-text font-bold">
                                                    <th className="p-2.5 font-mono">Date</th>
                                                    <th className="p-2.5 font-display">Investor Name</th>
                                                    <th className="p-2.5 font-display">Fund Description</th>
                                                    <th className="p-2.5 font-display">Brokerage Head</th>
                                                    <th className="p-2.5 font-display text-right">Amount (₹)</th>
                                                    <th className="p-2.5 font-display text-right">Units</th>
                                                    <th className="p-2.5 font-display text-right bg-accent-cream/30 text-accent-brown border-l border-r border-border-warm/20 font-bold">Rate (%)</th>
                                                    <th className="p-2.5 font-display text-right bg-amber-50 text-amber-800 border-r border-border-warm/20 font-bold">Brokerage (₹)</th>
                                                  </tr>
                                                </thead>
                                                <tbody className="divide-y divide-border-warm/40">
                                                  {buildKarvySummary(row._mergedRows || [], karvyColumnMap).map((sub, sIdx) => (
                                                    <tr key={sIdx} className="hover:bg-accent-cream/10 transition-colors">
                                                      <td className="p-2.5 font-mono text-muted-text">{sub['Transaction Date']}</td>
                                                      <td className="p-2.5 text-dark-text font-medium">{sub['Investor Name']}</td>
                                                      <td className="p-2.5 text-muted-text font-medium">{sub['Fund Description']}</td>
                                                      <td className="p-2.5">
                                                        <span className="inline-block px-1.5 py-0.5 rounded text-[9px] font-bold bg-accent-cream text-accent-brown">
                                                          {sub['Brokerage Head']}
                                                        </span>
                                                      </td>
                                                      <td className="p-2.5 font-mono text-right text-dark-text">₹{fmtNum(sub['Amount (₹)'])}</td>
                                                      <td className="p-2.5 font-mono text-right text-dark-text">{sub['Units']}</td>
                                                      <td className="p-2.5 font-mono text-right text-accent-brown bg-accent-cream/5 border-l border-r border-border-warm/20 font-semibold">{sub['Percentage (%)'].toFixed(4)}%</td>
                                                      <td className="p-2.5 font-mono text-right text-amber-900 bg-amber-50/15 border-r border-border-warm/20">₹{fmtNum(sub['Brokerage (₹)'])}</td>
                                                    </tr>
                                                  ))}
                                                </tbody>
                                              </table>
                                            </div>
                                          </td>
                                        </tr>
                                      )}
                                    </React.Fragment>
                                  );
                                })}
                              </tbody>
                            </table>
                          ) : (
                            /* ── Trail ERP v2 Table ── */
                            <table className="w-full text-left border-collapse text-xs">
                              <thead>
                                <tr className="bg-accent-cream/50 border-b border-border-warm text-muted-text font-bold text-[11px] uppercase tracking-wider">
                                  <th className="p-4 w-12 bg-accent-cream/50"></th>
                                  {renderSortableHeader("Investor Name", "Investor Name", "trail")}
                                  {renderSortableHeader("Scheme", "Scheme", "trail")}
                                  {renderSortableHeader("Folio", "Folio", "trail")}
                                  {renderSortableHeader("Proc Date", "Proc Date", "trail")}
                                  {renderSortableHeader("Trxn No", "Trxn No", "trail")}
                                  {renderSortableHeader("Type", "Type", "trail")}
                                  {renderSortableHeader("Units", "Units", "trail", true)}
                                  {renderSortableHeader("Amount", "Amount", "trail", true)}
                                  {renderSortableHeader("Rate (%)", "Rate", "trail", true, "bg-accent-cream/60 text-accent-brown border-l border-r border-border-warm/40 font-extrabold")}
                                  {renderSortableHeader("Fee Description", "Fee Desc", "trail")}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border-warm">
                                {paginatedTrail.map((row, idx) => {
                                  const hasMerged = row._mergedRows && row._mergedRows.length > 1;
                                  const isExpanded = !!expandedTrailRows[row['Trxn No'] + '_' + row['Folio'] + '_' + idx];
                                  return (
                                    <React.Fragment key={idx}>
                                      <tr className="hover:bg-accent-cream/20 transition-colors">
                                        <td className="p-4 text-center w-12">
                                          {hasMerged ? (
                                            <button 
                                              onClick={() => toggleTrailRow(row['Trxn No'] + '_' + row['Folio'] + '_' + idx)}
                                              className="p-1 hover:bg-accent-cream/80 text-accent-brown rounded transition-colors"
                                              title="View combined transactions"
                                            >
                                              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                                            </button>
                                          ) : (
                                            <span className="text-muted-text/30 font-mono text-[10px]">—</span>
                                          )}
                                        </td>
                                        <td className="p-4 font-semibold text-dark-text">{highlightMatchText(row['Investor Name'], tSearch)}</td>
                                        <td className="p-4 text-muted-text font-medium">{highlightMatchText(row['Scheme'], tSearch)}</td>
                                        <td className="p-4 font-mono font-medium text-dark-text">{highlightMatchText(row['Folio'], tSearch)}</td>
                                        <td className="p-4 font-mono text-muted-text">{row['Proc Date']}</td>
                                        <td className="p-4 font-mono text-muted-text">{highlightMatchText(row['Trxn No'], tSearch)}</td>
                                        <td className="p-4">
                                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                                            row['Type'] === 'P' ? 'bg-green-100 text-green-800' :
                                            row['Type'] === 'DR' ? 'bg-amber-100 text-amber-800' :
                                            row['Type'] === 'TI' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                                          }`}>
                                            {row['Type']}
                                          </span>
                                        </td>
                                        <td className="p-4 font-mono text-right font-medium text-dark-text">{fmtNum(row['Units'])}</td>
                                        <td className="p-4 font-mono text-right font-medium text-dark-text">{fmtNum(row['Amount'])}</td>
                                        <td className="p-4 font-mono text-right font-extrabold text-accent-brown bg-accent-cream/15 border-l border-r border-border-warm/40">{row['Rate'].toFixed(4)}%</td>
                                        <td className="p-4">
                                          <span className={`inline-block px-2 py-1 rounded text-[10px] text-muted-text font-bold bg-surface-bg border border-border-warm ${row['Fee Desc'].includes('|') ? 'border-dashed border-accent-brown text-accent-brown' : ''}`}>
                                            {row['Fee Desc'] || '—'}
                                          </span>
                                        </td>
                                      </tr>
                                      {isExpanded && (
                                        <tr className="bg-accent-cream/5">
                                          <td colSpan={11} className="p-4 border-b border-border-warm/80">
                                            <div className="bg-white/85 border border-border-warm/80 rounded-lg p-4 shadow-sm space-y-3">
                                              <div className="flex items-center justify-between">
                                                <h4 className="font-display font-extrabold text-accent-brown flex items-center gap-1.5 text-xs">
                                                  <Sparkles className="w-4 h-4 text-accent-brown animate-pulse" />
                                                  Consolidated Fee Breakdown ({row._mergedRows?.length} Rows Merged)
                                                </h4>
                                                <span className="text-[10px] text-muted-text font-bold">
                                                  Grouped by Folio: <strong className="font-mono text-dark-text">{row['Folio']}</strong>
                                                </span>
                                              </div>
                                              
                                              <table className="w-full text-left border-collapse text-[11px] bg-surface-bg border border-border-warm/60 rounded overflow-hidden">
                                                <thead>
                                                  <tr className="bg-accent-cream/40 border-b border-border-warm text-muted-text font-bold">
                                                    <th className="p-2.5 font-mono">Proc Date</th>
                                                    <th className="p-2.5 font-mono">Trxn No</th>
                                                    <th className="p-2.5 font-display">Investor Name</th>
                                                    <th className="p-2.5 font-display">Scheme</th>
                                                    <th className="p-2.5 font-display">Type</th>
                                                    <th className="p-2.5 font-display text-right">Units</th>
                                                    <th className="p-2.5 font-display text-right">Amount</th>
                                                    <th className="p-2.5 font-display text-right bg-accent-cream/30 text-accent-brown border-l border-r border-border-warm/20 font-bold">Rate (%)</th>
                                                    <th className="p-2.5 font-display">Fee Description</th>
                                                  </tr>
                                                </thead>
                                                <tbody className="divide-y divide-border-warm/40">
                                                  {buildTrailERPSummary(row._mergedRows || []).map((sub, sIdx) => (
                                                    <tr key={sIdx} className="hover:bg-accent-cream/10 transition-colors">
                                                      <td className="p-2.5 font-mono text-muted-text">{sub['Proc Date']}</td>
                                                      <td className="p-2.5 font-mono text-muted-text">{sub['Trxn No']}</td>
                                                      <td className="p-2.5 text-dark-text font-medium">{sub['Investor Name']}</td>
                                                      <td className="p-2.5 text-muted-text font-medium">{sub['Scheme']}</td>
                                                      <td className="p-2.5">
                                                        <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                                                          sub['Type'] === 'P' ? 'bg-green-100 text-green-800' :
                                                          sub['Type'] === 'DR' ? 'bg-amber-100 text-amber-800' :
                                                          sub['Type'] === 'TI' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                                                        }`}>
                                                          {sub['Type']}
                                                        </span>
                                                      </td>
                                                      <td className="p-2.5 font-mono text-right text-dark-text">{fmtNum(sub['Units'])}</td>
                                                      <td className="p-2.5 font-mono text-right text-dark-text">{fmtNum(sub['Amount'])}</td>
                                                      <td className="p-2.5 font-mono text-right text-accent-brown bg-accent-cream/5 border-l border-r border-border-warm/20 font-semibold">{sub['Rate'].toFixed(4)}%</td>
                                                      <td className="p-2.5">
                                                        <span className="inline-block px-1.5 py-0.5 rounded text-[9px] text-muted-text font-semibold bg-white border border-border-warm">
                                                          {sub['Fee Desc'] || '—'}
                                                        </span>
                                                      </td>
                                                    </tr>
                                                  ))}
                                                </tbody>
                                              </table>
                                            </div>
                                          </td>
                                        </tr>
                                      )}
                                    </React.Fragment>
                                  );
                                })}
                              </tbody>
                            </table>
                          )}

                          {/* Empty result view */}
                          {((activeERP === 'karvy' && !filteredKarvySummary.length) || (activeERP === 'trail_erp' && !filteredTrailSummary.length)) && (
                            <div className="p-12 text-center text-muted-text text-sm">
                              No records match the current filter query. Try modifying your search parameters.
                            </div>
                          )}

                        </div>

                        {/* DATAGRID PAGINATION CONTROLS */}
                        <div className="px-6 py-4 border-t border-border-warm bg-surface-bg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                          <p className="text-xs text-muted-text font-semibold">
                            {activeERP === 'karvy' ? (
                              `Showing page ${kPage} of ${totalKarvyPages} (Rows ${(kPage-1)*PAGE_SIZE + 1} – ${Math.min(kPage*PAGE_SIZE, filteredKarvySummary.length)} out of ${filteredKarvySummary.length} filtered)`
                            ) : (
                              `Showing page ${tPage} of ${totalTrailPages} (Rows ${(tPage-1)*PAGE_SIZE + 1} – ${Math.min(tPage*PAGE_SIZE, filteredTrailSummary.length)} out of ${filteredTrailSummary.length} filtered)`
                            )}
                          </p>

                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => {
                                if (activeERP === 'karvy') setKPage(p => Math.max(1, p - 1));
                                else setTPage(p => Math.max(1, p - 1));
                              }}
                              disabled={activeERP === 'karvy' ? kPage === 1 : tPage === 1}
                              className="px-3 py-1.5 bg-white hover:bg-accent-cream border border-border-warm rounded-lg text-xs font-bold text-dark-text disabled:opacity-40 disabled:pointer-events-none transition-colors premium-shadow cursor-pointer"
                            >
                              ‹ Prev
                            </button>
                            
                            {activeERP === 'karvy' ? (
                              Array.from({ length: Math.min(5, totalKarvyPages) }, (_, i) => {
                                // show pages centered around current page
                                let pNum = i + 1;
                                if (kPage > 3) pNum = kPage - 3 + i;
                                if (pNum > totalKarvyPages) return null;
                                return (
                                  <button 
                                    key={i}
                                    onClick={() => setKPage(pNum)}
                                    className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${kPage === pNum ? 'bg-accent-brown text-white' : 'bg-white hover:bg-accent-cream text-dark-text'}`}
                                  >
                                    {pNum}
                                  </button>
                                );
                              })
                            ) : (
                              Array.from({ length: Math.min(5, totalTrailPages) }, (_, i) => {
                                let pNum = i + 1;
                                if (tPage > 3) pNum = tPage - 3 + i;
                                if (pNum > totalTrailPages) return null;
                                return (
                                  <button 
                                    key={i}
                                    onClick={() => setTPage(pNum)}
                                    className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${tPage === pNum ? 'bg-accent-brown text-white' : 'bg-white hover:bg-accent-cream text-dark-text'}`}
                                  >
                                    {pNum}
                                  </button>
                                );
                              })
                            )}

                            <button 
                              onClick={() => {
                                if (activeERP === 'karvy') setKPage(p => Math.min(totalKarvyPages, p + 1));
                                else setTPage(p => Math.min(totalTrailPages, p + 1));
                              }}
                              disabled={activeERP === 'karvy' ? kPage === totalKarvyPages : tPage === totalTrailPages}
                              className="px-3 py-1.5 bg-white hover:bg-accent-cream border border-border-warm rounded-lg text-xs font-bold text-dark-text disabled:opacity-40 disabled:pointer-events-none transition-colors premium-shadow cursor-pointer"
                            >
                              Next ›
                            </button>
                          </div>
                        </div>
                      </motion.div>

                    </div>
                  )}

                </motion.div>
              )}

              {/* PAGE 4: EXECUTIVE STATS & ANALYTICS DASHBOARD */}
              {activeSubPage === 'analytics' && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Stats Grid Overview */}
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                    
                    {/* Card 1: Uncleaned Rows */}
                    <div 
                      onMouseEnter={() => setHoveredStat('uncleaned')}
                      onMouseLeave={() => setHoveredStat(null)}
                      className={`group relative overflow-hidden bg-white border rounded-xl p-5 transition-all duration-300 premium-shadow cursor-help select-none ${
                        hoveredStat === 'uncleaned' ? 'border-accent-brown bg-accent-cream/20 shadow-lg scale-[1.02]' : 'border-border-warm hover:border-accent-brown/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider">Uncleaned Rows</p>
                        <span className="w-2 h-2 rounded-full bg-accent-brown/80 group-hover:scale-125 transition-transform duration-300"></span>
                      </div>
                      <h4 className="text-2xl font-extrabold text-dark-text mt-2 font-mono">{statsSummary.rawCount}</h4>
                      
                      {/* Sparkline */}
                      <div className="mt-3 h-8 flex items-end justify-between">
                        <span className="text-[10px] text-muted-text font-medium">Raw slab entries</span>
                        <svg className="w-16 h-6 text-accent-brown shrink-0" viewBox="0 0 60 20">
                          <path d="M 0,14 Q 15,3 30,16 T 60,8" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                      </div>
                      
                      {/* Micro insight snippet on hover */}
                      <AnimatePresence>
                        {hoveredStat === 'uncleaned' && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute inset-0 bg-accent-brown text-white p-4 flex flex-col justify-between text-[11px] rounded-xl"
                          >
                            <p className="font-bold uppercase tracking-wider text-[9px] text-accent-cream">Raw Load Ingestion</p>
                            <p className="leading-tight mt-1">Slabs count before execution. Represents complete unprocessed multi-tier commission splits.</p>
                            <p className="text-[9px] text-accent-cream/80 mt-2 font-mono">ID: INGEST_POOL_A</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Card 2: Cleaned Ledgers */}
                    <div 
                      onMouseEnter={() => setHoveredStat('cleaned')}
                      onMouseLeave={() => setHoveredStat(null)}
                      className={`group relative overflow-hidden bg-white border rounded-xl p-5 transition-all duration-300 premium-shadow cursor-help select-none ${
                        hoveredStat === 'cleaned' ? 'border-accent-brown bg-accent-cream/20 shadow-lg scale-[1.02]' : 'border-border-warm hover:border-accent-brown/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider">Cleaned Ledgers</p>
                        <span className="w-2 h-2 rounded-full bg-green-600 group-hover:scale-125 transition-transform duration-300 animate-pulse"></span>
                      </div>
                      <h4 className="text-2xl font-extrabold text-accent-brown mt-2 font-mono">{statsSummary.cleanedCount}</h4>
                      
                      {/* Sparkline */}
                      <div className="mt-3 h-8 flex items-end justify-between">
                        <span className="text-[10px] text-muted-text font-medium">After deduplication</span>
                        <svg className="w-16 h-6 text-green-700 shrink-0" viewBox="0 0 60 20">
                          <path d="M 0,18 L 15,10 L 30,12 L 45,5 L 60,2" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                      </div>

                      {/* Micro insight snippet on hover */}
                      <AnimatePresence>
                        {hoveredStat === 'cleaned' && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute inset-0 bg-green-800 text-white p-4 flex flex-col justify-between text-[11px] rounded-xl font-sans"
                          >
                            <p className="font-bold uppercase tracking-wider text-[9px] text-green-200">Ledger Health Score</p>
                            <p className="leading-tight mt-1 font-sans">100% reconciled database rows. Verified folio mappings, sorted chronologically with zero duplicates.</p>
                            <p className="text-[9px] text-green-200/80 mt-2 font-mono font-sans">STATUS: STABLE_OK</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Card 3: Merged Rows */}
                    <div 
                      onMouseEnter={() => setHoveredStat('merged')}
                      onMouseLeave={() => setHoveredStat(null)}
                      className={`group relative overflow-hidden bg-white border rounded-xl p-5 transition-all duration-300 premium-shadow cursor-help select-none ${
                        hoveredStat === 'merged' ? 'border-accent-brown bg-accent-cream/20 shadow-lg scale-[1.02]' : 'border-border-warm hover:border-accent-brown/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider">Merged Rows</p>
                        <span className="w-2 h-2 rounded-full bg-red-600 group-hover:scale-125 transition-transform duration-300"></span>
                      </div>
                      <h4 className="text-2xl font-extrabold text-red-700 mt-2 font-mono">{statsSummary.rowsMergedCount}</h4>
                      
                      {/* Sparkline */}
                      <div className="mt-3 h-8 flex items-end justify-between">
                        <span className="text-[10px] text-muted-text font-medium">Redundancies purged</span>
                        <svg className="w-16 h-6 text-red-700 shrink-0" viewBox="0 0 60 20">
                          <path d="M 0,2 C 15,12 30,12 45,5 T 60,18" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                      </div>

                      {/* Micro insight snippet on hover */}
                      <AnimatePresence>
                        {hoveredStat === 'merged' && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute inset-0 bg-red-700 text-white p-4 flex flex-col justify-between text-[11px] rounded-xl"
                          >
                            <p className="font-bold uppercase tracking-wider text-[9px] text-red-200">Purged Redundancies</p>
                            <p className="leading-tight mt-1">Separate identical sub-lots that were successfully consolidated into master rate tiers.</p>
                            <p className="text-[9px] text-red-200/80 mt-2 font-mono">PURGE_RATIO: {(((statsSummary.rowsMergedCount || 0) / (statsSummary.rawCount || 1)) * 100).toFixed(1)}%</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Card 4: Unique Clients */}
                    <div 
                      onMouseEnter={() => setHoveredStat('clients')}
                      onMouseLeave={() => setHoveredStat(null)}
                      className={`group relative overflow-hidden bg-white border rounded-xl p-5 transition-all duration-300 premium-shadow cursor-help select-none ${
                        hoveredStat === 'clients' ? 'border-accent-brown bg-accent-cream/20 shadow-lg scale-[1.02]' : 'border-border-warm hover:border-accent-brown/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider">Unique Clients</p>
                        <span className="w-2 h-2 rounded-full bg-blue-600 group-hover:scale-125 transition-transform duration-300"></span>
                      </div>
                      <h4 className="text-2xl font-extrabold text-dark-text mt-2 font-mono">{statsSummary.uniqueInvestors}</h4>
                      
                      {/* Sparkline */}
                      <div className="mt-3 h-8 flex items-end justify-between">
                        <span className="text-[10px] text-muted-text font-medium">MF Investors</span>
                        <svg className="w-16 h-6 text-blue-600 shrink-0" viewBox="0 0 60 20">
                          <path d="M 0,15 T 20,12 T 40,6 T 60,5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                      </div>

                      {/* Micro insight snippet on hover */}
                      <AnimatePresence>
                        {hoveredStat === 'clients' && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute inset-0 bg-blue-800 text-white p-4 flex flex-col justify-between text-[11px] rounded-xl"
                          >
                            <p className="font-bold uppercase tracking-wider text-[9px] text-blue-200">Investor Density</p>
                            <p className="leading-tight mt-1">Total distinct investor name identifiers tracked in this active ledger sheet.</p>
                            <p className="text-[9px] text-blue-200/80 mt-2 font-mono">CLASS: CORPORATE / RETAIL</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Card 5: Unique Accounts */}
                    <div 
                      onMouseEnter={() => setHoveredStat('accounts')}
                      onMouseLeave={() => setHoveredStat(null)}
                      className={`group relative overflow-hidden bg-white border rounded-xl p-5 transition-all duration-300 premium-shadow cursor-help select-none ${
                        hoveredStat === 'accounts' ? 'border-accent-brown bg-accent-cream/20 shadow-lg scale-[1.02]' : 'border-border-warm hover:border-accent-brown/50'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider">Unique Accounts</p>
                        <span className="w-2 h-2 rounded-full bg-amber-600 group-hover:scale-125 transition-transform duration-300"></span>
                      </div>
                      <h4 className="text-2xl font-extrabold text-dark-text mt-2 font-mono">{statsSummary.uniqueAccounts}</h4>
                      
                      {/* Sparkline */}
                      <div className="mt-3 h-8 flex items-end justify-between">
                        <span className="text-[10px] text-muted-text font-medium">Monitored folios</span>
                        <svg className="w-16 h-6 text-amber-600 shrink-0" viewBox="0 0 60 20">
                          <path d="M 0,12 L 15,6 L 30,15 L 45,8 L 60,5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                        </svg>
                      </div>

                      {/* Micro insight snippet on hover */}
                      <AnimatePresence>
                        {hoveredStat === 'accounts' && (
                          <motion.div 
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 5 }}
                            className="absolute inset-0 bg-amber-700 text-white p-4 flex flex-col justify-between text-[11px] rounded-xl"
                          >
                            <p className="font-bold uppercase tracking-wider text-[9px] text-amber-200">Account Mapping</p>
                            <p className="leading-tight mt-1">Total unique folio numbers. Individual clients may hold multiple portfolios.</p>
                            <p className="text-[9px] text-amber-200/80 mt-2 font-mono">DENSITY: COHESIVE</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                  </div>

                  {/* Dynamic Drill-Down Insight Drawer Banner */}
                  <div className="bg-accent-cream/30 border border-border-warm rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 premium-shadow relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-2 opacity-5">
                      <Sparkles className="w-16 h-16 text-accent-brown" />
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white border border-border-warm rounded-lg flex items-center justify-center text-accent-brown shrink-0 premium-shadow">
                        <Sliders className="w-5 h-5 animate-pulse" />
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-accent-brown uppercase tracking-wider">Dynamic Drill-Down Insight</p>
                        <h4 className="text-xs sm:text-sm font-semibold text-dark-text mt-0.5">
                          {!hoveredStat && 'Hover over any Bento summary card to view deep statistical analytics and ratio reviews.'}
                          {hoveredStat === 'uncleaned' && `Batch Ingestion Check: Out of ${statsSummary.rawCount} rows, zero corrupt structures were detected. Fee components include LongTermTrail, incentive slabs, and base rates.`}
                          {hoveredStat === 'cleaned' && `Deduplication efficiency stands at ${(((statsSummary.rowsMergedCount || 0) / (statsSummary.rawCount || 1)) * 100).toFixed(1)}%. Successfully merged separate broker commissions and transaction splits into ${statsSummary.cleanedCount} unified records.`}
                          {hoveredStat === 'merged' && `Purge rate has cleared ${statsSummary.rowsMergedCount} duplicates. Collapsing identical sub-lots avoids double counting and simplifies administrative reporting.`}
                          {hoveredStat === 'clients' && `Concentration Check: Total unique investors count ${statsSummary.uniqueInvestors}. Average brokerage/weight per client is ₹${(statsSummary.totalBrokerageOrRate / (statsSummary.uniqueInvestors || 1)).toFixed(2)}.`}
                          {hoveredStat === 'accounts' && `Folio density score: ${((statsSummary.uniqueAccounts || 1) / (statsSummary.uniqueInvestors || 1)).toFixed(2)} accounts per unique investor. Strong mapping structures keep multiple folios organized.`}
                        </h4>
                      </div>
                    </div>
                    <div className="text-[10px] bg-white border border-border-warm px-2.5 py-1 rounded text-muted-text font-bold uppercase tracking-wider shadow-sm shrink-0">
                      {!hoveredStat ? 'Standby Mode' : `${hoveredStat.toUpperCase()} ACTIVE`}
                    </div>
                  </div>

                  {/* Deep Analysis & Quick Reports */}
                  {((activeERP === 'karvy' && !karvySummaryRows.length) || (activeERP === 'trail_erp' && !trailSummaryRows.length)) ? (
                    <div className="bg-white border border-border-warm rounded-xl p-8 text-center premium-shadow max-w-md mx-auto">
                      <TrendingUp className="w-10 h-10 text-border-warm mx-auto mb-3" />
                      <h4 className="text-sm font-bold text-dark-text">No Analytical Summary Compiled</h4>
                      <p className="text-xs text-muted-text mt-1 leading-relaxed">Please import a spreadsheet or load demo datasets to view statistical charts.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      
                      {/* Left: Total Sum Highlights */}
                      <div className="bg-white border border-border-warm rounded-xl p-6 premium-shadow lg:col-span-1 space-y-5">
                        <div>
                          <p className="text-[10px] font-bold text-muted-text uppercase tracking-wider font-display">Financial Overview</p>
                          <h3 className="text-base font-bold text-dark-text mt-0.5">
                            {activeERP === 'karvy' ? 'Accumulated Brokerage' : 'Accumulated Yield Rate'}
                          </h3>
                        </div>

                        <div className="p-5 bg-accent-cream rounded-xl border border-border-warm">
                          <p className="text-xs text-muted-text font-medium">Consolidated Total Value</p>
                          <h2 className="text-2xl font-extrabold text-accent-brown font-mono mt-1">
                            {activeERP === 'karvy' 
                              ? `₹${fmtNum(statsSummary.totalBrokerageOrRate)}`
                              : `${(statsSummary.totalBrokerageOrRate || 0).toFixed(4)}%`
                            }
                          </h2>
                          <p className="text-[10px] text-muted-text mt-1.5 font-medium">
                            {activeERP === 'karvy' ? 'Total distributor commission' : 'Aggregated fee rate weight'}
                          </p>
                        </div>

                        {/* Audit Details */}
                        <div className="space-y-3 text-xs">
                          <div className="flex justify-between border-b border-border-warm pb-2">
                            <span className="text-muted-text font-medium">Aggregator Audit Check</span>
                            <span className="font-bold text-green-700">PASS</span>
                          </div>
                          <div className="flex justify-between border-b border-border-warm pb-2">
                            <span className="text-muted-text font-medium">Deduplication Ratio</span>
                            <span className="font-bold text-dark-text font-mono">
                              {(((statsSummary.rowsMergedCount || 0) / (statsSummary.rawCount || 1)) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex justify-between border-b border-border-warm pb-2">
                            <span className="text-muted-text font-medium">Average Slabs per Trxn</span>
                            <span className="font-bold text-dark-text font-mono">
                              {((statsSummary.rawCount || 1) / (statsSummary.cleanedCount || 1)).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right: Breakdown of Top Investors and Top Schemes */}
                      <div className="bg-white border border-border-warm rounded-xl p-6 premium-shadow lg:col-span-2 space-y-4">
                        <h4 className="text-xs font-bold text-dark-text uppercase tracking-wider font-display">
                          Key Client Distribution &amp; Concentration
                        </h4>
                        
                        <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar pr-1">
                          {activeERP === 'karvy' ? (
                            karvySummaryRows.slice(0, 8).map((row, idx) => (
                              <div key={idx} className="flex items-center justify-between p-3 bg-surface-bg rounded-lg border border-border-warm">
                                <div className="flex items-center gap-3">
                                  <span className="w-6 h-6 bg-accent-cream rounded-full flex items-center justify-center text-[10px] font-extrabold text-accent-brown border border-border-warm">
                                    {idx + 1}
                                  </span>
                                  <div>
                                    <h5 className="text-xs font-bold text-dark-text">{row['Investor Name']}</h5>
                                    <p className="text-[10px] text-muted-text font-medium">{row['Fund Description']}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <span className="text-xs font-bold text-dark-text font-mono">₹{fmtNum(row['Brokerage (₹)'])}</span>
                                  <p className="text-[10px] text-accent-brown font-mono font-medium">{row['Percentage (%)'].toFixed(3)}% rate</p>
                                </div>
                              </div>
                            ))
                          ) : (
                            trailSummaryRows.slice(0, 8).map((row, idx) => (
                              <div key={idx} className="flex items-center justify-between p-3 bg-surface-bg rounded-lg border border-border-warm">
                                <div className="flex items-center gap-3">
                                  <span className="w-6 h-6 bg-accent-cream rounded-full flex items-center justify-center text-[10px] font-extrabold text-accent-brown border border-border-warm">
                                    {idx + 1}
                                  </span>
                                  <div>
                                    <h5 className="text-xs font-bold text-dark-text">{row['Investor Name']}</h5>
                                    <p className="text-[10px] text-muted-text font-medium">{row['Scheme']}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <span className="text-xs font-bold text-accent-brown font-mono">{row['Rate'].toFixed(4)}%</span>
                                  <p className="text-[10px] text-muted-text font-medium">{row['Type']} purchase</p>
                                </div>
                              </div>
                            ))
                          )}
                        </div>

                      </div>

                    </div>
                  )}

                </div>
              )}

            </div>

            {/* Premium Console Footer */}
            <footer className="mt-auto px-8 py-4 border-t border-border-warm bg-surface-bg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 text-xs text-muted-text font-semibold">
              <div>
                © 2026 Karvy &amp; CAMS MF Brokerage Cleaner Portal. All rights reserved.
              </div>
              <div className="flex items-center gap-4">
                <span>Secure Session: <strong>{userEmail}</strong></span>
                <span className="hidden sm:inline">|</span>
                <span>Client Sandbox: <strong>100% Local</strong></span>
              </div>
            </footer>

          </main>

        </div>
      )}

    </div>
  );
}
