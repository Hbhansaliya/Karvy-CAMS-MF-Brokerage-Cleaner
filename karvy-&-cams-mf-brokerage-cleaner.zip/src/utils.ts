import { KarvySummaryRow, TrailERPSummaryRow } from './types';

// Flexible alias matches for Karvy Columns
export const KARVY_COLUMNS = {
  acct: ['account number', 'folio', 'account no'],
  group: ['group code'],
  amc: ['amc'],
  investor: ['investor name', 'investor'],
  fund: ['fund description', 'scheme', 'fund name'],
  pct: ['percentage (%)', 'percentage', 'rate', 'trail rate', 'addtrail rate', 'percentage(%)'],
  brok: ['brokerage (in rs.)', 'brokerage', 'fee amount', 'brokerage(in rs.)', 'amount'],
  desc: ['transaction description', 'trxn description', 'trxn type', 'transaction type'],
  head: ['brokerage head', 'fee head', 'trail head'],
  amt: ['amount (in rs.)', 'investment amount', 'trxn amount', 'amount(in rs.)'],
  units: ['units'],
  date: ['transaction date', 'trxn date', 'date'],
  trxnno: ['transaction number', 'trxn number', 'transaction no', 'trxn no'],
};

export function parseDate(v: any): number {
  if (!v) return 0;
  if (typeof v === 'number' && v > 40000 && v < 60000) return v; // Excel serial
  const d = new Date(v);
  return isNaN(d.getTime()) ? 0 : d.getTime() / 86400000;
}

export function fmtDate(v: any): string {
  if (!v) return '';
  if (typeof v === 'number' && v > 40000 && v < 70000) {
    const d = new Date(Date.UTC(1899, 11, 30) + v * 86400000);
    return `${String(d.getUTCDate()).padStart(2, '0')}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${d.getUTCFullYear()}`;
  }
  if (typeof v === 'string' && v.includes('-')) {
    const parts = v.split('T')[0].split('-');
    if (parts.length === 3) {
      if (parts[0].length === 4) {
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      return v;
    }
  }
  return String(v);
}

export function serialToDate(serial: any): string {
  const v = parseFloat(serial);
  if (isNaN(v) || v < 30000) return serial || '';
  const intPart = Math.floor(v);
  const frac = v - intPart;
  const d = new Date(Date.UTC(1899, 11, 30) + intPart * 86400000);
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const yyyy = d.getUTCFullYear();
  if (frac > 0.001) {
    const h = Math.floor(frac * 24);
    const min = Math.floor((frac * 24 - h) * 60);
    return `${dd}-${mm}-${yyyy} ${String(h).padStart(2, '0')}:${String(min).padStart(2, '0')}`;
  }
  return `${dd}-${mm}-${yyyy}`;
}

export function fmtNum(v: any): string {
  const n = parseFloat(v);
  if (isNaN(n)) return v !== undefined && v !== null ? String(v) : '';
  return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Map column aliases dynamically
export function mapColumnNames(headers: string[]): Record<string, string | null> {
  const hLower = headers.map(h => h.toLowerCase());
  const resolve = (aliases: string[]) => {
    for (const a of aliases) {
      const i = hLower.indexOf(a);
      if (i >= 0) return headers[i];
    }
    return null;
  };

  const C: Record<string, string | null> = {};
  for (const [k, aliases] of Object.entries(KARVY_COLUMNS)) {
    C[k] = resolve(aliases);
  }
  return C;
}

// ── Karvy Consolidation Engine ──
export function consolidateKarvy(data: any[], C: Record<string, string | null>): any[] {
  const trxnKey = C.trxnno || 'Transaction Number';
  const pctKey = C.pct || 'Percentage (%)';
  const brokKey = C.brok || 'Brokerage (in Rs.)';
  const unitsKey = C.units || 'Units';
  const headKey = C.head || 'Brokerage Head';
  const investorKey = C.investor || 'Investor Name';
  const fundKey = C.fund || 'Fund Description';
  const dateKey = C.date || 'Transaction Date';

  // Group by Transaction Number
  const groups = new Map<string, any[]>();
  data.forEach(row => {
    const tn = String(row[trxnKey] || '').trim();
    if (!groups.has(tn)) groups.set(tn, []);
    groups.get(tn)!.push(row);
  });

  const result: any[] = [];

  groups.forEach((grpRows, tn) => {
    if (grpRows.length === 1) {
      const single = Object.assign({}, grpRows[0]);
      single._originalRows = grpRows;
      result.push(single);
      return;
    }

    // Merge: take first row as base
    const base = Object.assign({}, grpRows[0]);
    base._originalRows = grpRows;

    // Check if the Transaction Number, Transaction date and Amount, all is same
    const amtKey = C.amt || 'Amount (in Rs.)';
    const firstDate = String(grpRows[0][dateKey] || '').trim();
    const firstAmt = parseFloat(grpRows[0][amtKey]) || 0;
    const firstTrxn = String(grpRows[0][trxnKey] || '').trim();

    const sameDate = grpRows.every(r => String(r[dateKey] || '').trim() === firstDate);
    const sameAmt = grpRows.every(r => (parseFloat(r[amtKey]) || 0) === firstAmt);
    const sameTrxn = grpRows.every(r => String(r[trxnKey] || '').trim() === firstTrxn);

    if (sameDate && sameAmt && sameTrxn) {
      // If all rows have the same Trxn No, Date, and Amount, show only the one percentage
      base[pctKey] = parseFloat((parseFloat(grpRows[0][pctKey]) || 0).toFixed(6));
      base[amtKey] = firstAmt;
    } else {
      // Sum Rate
      const pctSum = grpRows.reduce((s, r) => s + (parseFloat(r[pctKey]) || 0), 0);
      base[pctKey] = parseFloat(pctSum.toFixed(6));
      // Sum Amount
      const amtSum = grpRows.reduce((s, r) => s + (parseFloat(r[amtKey]) || 0), 0);
      base[amtKey] = amtSum;
    }

    // Sum Brokerage
    const brokSum = grpRows.reduce((s, r) => s + (parseFloat(r[brokKey]) || 0), 0);
    base[brokKey] = parseFloat(brokSum.toFixed(2));

    // Sum Units (if sub-lots differ)
    if (unitsKey) {
      const unitsVals = grpRows.map(r => parseFloat(r[unitsKey]) || 0);
      const uniqueUnits = [...new Set(unitsVals.map(v => v.toFixed(3)))];
      base[unitsKey] = uniqueUnits.length === 1
        ? grpRows[0][unitsKey]
        : parseFloat(unitsVals.reduce((a, b) => a + b, 0).toFixed(3));
    }

    // Combine Unique Heads
    const uniqueHeads = [...new Set(grpRows.map(r => String(r[headKey] || '').trim()).filter(Boolean))];
    base[headKey] = uniqueHeads.join(' + ');

    result.push(base);
  });

  // FIFO Sort: Investor → Fund → Date → Trxn No
  result.sort((a, b) => {
    const inv = String(a[investorKey] || '').localeCompare(String(b[investorKey] || ''));
    if (inv !== 0) return inv;
    const fund = String(a[fundKey] || '').localeCompare(String(b[fundKey] || ''));
    if (fund !== 0) return fund;
    const da = parseDate(a[dateKey]), db = parseDate(b[dateKey]);
    if (da !== db) return da - db;
    return parseFloat(a[trxnKey] || 0) - parseFloat(b[trxnKey] || 0);
  });

  return result;
}

export function buildKarvySummary(rows: any[], C: Record<string, string | null>): KarvySummaryRow[] {
  return rows.map(r => ({
    'Account No': r[C.acct || 'Account No'] || '',
    'Investor Name': r[C.investor || 'Investor Name'] || '',
    'Fund Description': r[C.fund || 'Fund Description'] || '',
    'Trxn Type': r[C.desc || 'Transaction Description'] || '',
    'Transaction Date': fmtDate(r[C.date || 'Transaction Date']),
    'Transaction No': r[C.trxnno || 'Transaction Number'] || '',
    'Amount (₹)': r[C.amt || 'Amount (in Rs.)'] || '',
    'Units': r[C.units || 'Units'] || '',
    'Percentage (%)': r[C.pct || 'Percentage (%)'] || 0,
    'Brokerage (₹)': r[C.brok || 'Brokerage (in Rs.)'] || 0,
    'Brokerage Head': r[C.head || 'Brokerage Head'] || '',
    _date_raw: parseDate(r[C.date || 'Transaction Date']),
    _investor: String(r[C.investor || ''] || '').toLowerCase(),
    _fund: String(r[C.fund || ''] || '').toLowerCase(),
    _acct: String(r[C.acct || ''] || ''),
    _head: String(r[C.head || ''] || '').toLowerCase(),
    _desc: String(r[C.desc || ''] || '').toLowerCase(),
    _mergedRows: r._originalRows || [r],
  }));
}

// ── CAMS MF Brokerage Cleaner Consolidation Engine ──
export function processTrailERP(data: any[], allHeaders: string[]): any[] {
  const n = (v: any) => (v === null || v === undefined || v === '') ? '' : String(v).trim();

  // Columns to IGNORE when grouping (fee_amt excluded + rate/fee_desc are aggregated)
  const IGNORE = new Set(['rate', 'fee_amt', 'avg_assets', 'fee_type', 'days_fee_paid', 'fee_desc']);
  const KEY_COL = allHeaders.filter(h => !IGNORE.has(h.toLowerCase()));

  const groupKey = (row: any) => KEY_COL.map(h => n(row[h])).join('|||');
  const fullKey = (row: any) => allHeaders.map(h => n(row[h])).join('|||');

  // Step 1: Remove exact full duplicates
  const seenFull = new Set<string>();
  const dedup1 = data.filter(row => {
    const k = fullKey(row);
    if (seenFull.has(k)) return false;
    seenFull.add(k);
    return true;
  });

  // Step 2: Group by key cols → sum rate, combine fee_desc (ignore fee_amt)
  const groups = new Map<string, any[]>();
  dedup1.forEach(row => {
    const k = groupKey(row);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k)!.push(row);
  });

  const result: any[] = [];
  groups.forEach(grpRows => {
    if (grpRows.length === 1) {
      const single = Object.assign({}, grpRows[0]);
      single._originalRows = grpRows;
      result.push(single);
      return;
    }

    const merged = Object.assign({}, grpRows[0]);
    merged._originalRows = grpRows;

    // Check if Transaction Number (trxn_no), Proc Date (procdate), and Amount (amount) are same
    const sameDateTrail = grpRows.every(r => String(r['procdate'] || '').trim() === String(grpRows[0]['procdate'] || '').trim());
    const sameAmtTrail = grpRows.every(r => (parseFloat(r['amount']) || 0) === (parseFloat(grpRows[0]['amount']) || 0));
    const sameTrxnTrail = grpRows.every(r => String(r['trxn_no'] || '').trim() === String(grpRows[0]['trxn_no'] || '').trim());

    if (sameDateTrail && sameAmtTrail && sameTrxnTrail) {
      merged['rate'] = parseFloat((parseFloat(grpRows[0]['rate']) || 0).toFixed(6));
      merged['amount'] = parseFloat(grpRows[0]['amount']) || 0;
    } else {
      merged['rate'] = grpRows.reduce((sum, r) => sum + (parseFloat(r['rate']) || 0), 0);
      merged['rate'] = parseFloat(merged['rate'].toFixed(6));
      merged['amount'] = grpRows.reduce((sum, r) => sum + (parseFloat(r['amount']) || 0), 0);
    }

    // Combine fee_desc
    const descs = [...new Set(grpRows.map(r => String(r['fee_desc'] || '')).filter(Boolean))];
    merged['fee_desc'] = descs.join(' | ');
    // Sum fee_amt
    merged['fee_amt'] = grpRows.reduce((sum, r) => sum + (parseFloat(r['fee_amt']) || 0), 0).toFixed(2);
    // Sum avg_assets
    merged['avg_assets'] = grpRows.reduce((sum, r) => sum + (parseFloat(r['avg_assets']) || 0), 0).toFixed(2);
    // Combine fee_type and days_fee_paid
    merged['fee_type'] = [...new Set(grpRows.map(r => String(r['fee_type'] || '')).filter(Boolean))].join(' | ');
    merged['days_fee_paid'] = [...new Set(grpRows.map(r => String(r['days_fee_paid'] || '')).filter(Boolean))].join(' | ');

    result.push(merged);
  });

  // Step 3: FIFO sort — Investor → Scheme → Folio → procdate → trxn_no
  result.sort((a, b) => {
    const inv = String(a['investor name'] || '').localeCompare(String(b['investor name'] || ''));
    if (inv !== 0) return inv;
    const sch = String(a['short_name'] || '').localeCompare(String(b['short_name'] || ''));
    if (sch !== 0) return sch;
    const fol = String(a['folio'] || '').localeCompare(String(b['folio'] || ''));
    if (fol !== 0) return fol;
    const pd = parseFloat(a['procdate'] || 0) - parseFloat(b['procdate'] || 0);
    if (pd !== 0) return pd;
    return parseFloat(a['trxn_no'] || 0) - parseFloat(b['trxn_no'] || 0);
  });

  return result;
}

export function buildTrailERPSummary(rows: any[]): TrailERPSummaryRow[] {
  return rows.map(r => ({
    'Investor Name': r['investor name'] || '',
    'Scheme': r['short_name'] || '',
    'Folio': r['folio'] || '',
    'Proc Date': serialToDate(r['procdate']),
    'Trxn No': r['trxn_no'] || '',
    'Type': String(r['trxn_db_cr'] || '').toUpperCase(),
    'Units': r['units'] || '',
    'Amount': r['amount'] || '',
    'Rate': r['rate'] || 0,
    'Fee Desc': r['fee_desc'] || '',
    _procdate_raw: parseFloat(r['procdate'] || 0),
    _mergedRows: r._originalRows || [r]
  }));
}
