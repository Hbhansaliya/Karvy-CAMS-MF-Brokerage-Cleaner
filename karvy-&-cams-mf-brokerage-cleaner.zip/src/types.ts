export type ERPType = 'karvy' | 'trail_erp' | null;

// Raw rows are records of keys and values
export type RawRow = Record<string, any>;

// Tool 1: Karvy Row Schema
export interface KarvySummaryRow {
  'Account No': string;
  'Investor Name': string;
  'Fund Description': string;
  'Trxn Type': string;
  'Transaction Date': string;
  'Transaction No': string;
  'Amount (₹)': string | number;
  'Units': string | number;
  'Percentage (%)': number;
  'Brokerage (₹)': number;
  'Brokerage Head': string;
  _date_raw: number;
  _investor: string;
  _fund: string;
  _acct: string;
  _head: string;
  _desc: string;
  _mergedRows?: any[];
}

// Tool 2: CAMS MF Brokerage Cleaner Row Schema
export interface TrailERPSummaryRow {
  'Investor Name': string;
  'Scheme': string;
  'Folio': string;
  'Proc Date': string;
  'Trxn No': string;
  'Type': string;
  'Units': string | number;
  'Amount': string | number;
  'Rate': number;
  'Fee Desc': string;
  _procdate_raw: number;
  _mergedRows?: any[];
}

export interface ERPStats {
  rawCount: number;
  cleanedCount: number;
  rowsMergedCount: number;
  uniqueInvestors: number;
  uniqueAccounts: number;
  totalBrokerageOrRate?: number;
}
